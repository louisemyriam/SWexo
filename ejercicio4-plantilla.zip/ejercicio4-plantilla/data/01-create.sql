BEGIN TRANSACTION;
DROP TABLE IF EXISTS "Usuarios";
CREATE TABLE "Usuarios" (
	"id"		INTEGER NOT NULL,
	"username"	TEXT NOT NULL UNIQUE,
	"password"	TEXT NOT NULL,
	"rol"		TEXT NOT NULL DEFAULT 'U' CHECK("rol" IN ('U', 'A')),
	"nombre"	TEXT NOT NULL,
	"apellidos"	TEXT NOT NULL,
	"email"		TEXT NOT NULL,
	"avatar"	TEXT,
	PRIMARY KEY("id" AUTOINCREMENT)
);
COMMIT;
