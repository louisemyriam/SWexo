BEGIN TRANSACTION;
-- user: userpass
-- admin: adminpass
INSERT INTO 'Usuarios' ('id', 'username', 'password', 'rol', 'nombre', 'apellidos', 'email') VALUES
(1, 'user', '$2b$10$JdCg8yL3rRkkr.hhx1rjqOe30F9lhBlqA1sjYJW6ymzYExvQFHyjy', 'U', 'Usuario', 'Apellidos', 'user@example.org')
, (2, 'admin', '$2b$10$Htah5iG9eKj8ItIItpzK6uvny3c5/QjdZaLwwmFy32RPrfVspNgYS', 'A', 'Administrador', 'Apellidos', 'admin@example.org')
;

-- Datos de: https://reqres.in
-- password: userpass
INSERT INTO 'Usuarios' ('password', 'username', 'nombre', 'apellidos', 'email', 'avatar') VALUES
('$2b$10$JdCg8yL3rRkkr.hhx1rjqOe30F9lhBlqA1sjYJW6ymzYExvQFHyjy', 'george.bluth', 'George', 'Bluth', 'george.bluth@reqres.in', '3.jpg')
, ('$2b$10$JdCg8yL3rRkkr.hhx1rjqOe30F9lhBlqA1sjYJW6ymzYExvQFHyjy', 'janet.weaver', 'Lindsay', 'Ferguson', 'janet.weaver@reqres.in', '4.jpg')
, ('$2b$10$JdCg8yL3rRkkr.hhx1rjqOe30F9lhBlqA1sjYJW6ymzYExvQFHyjy', 'emma.wong', 'Emma', 'Wong', 'emma.wong@reqres.in', '5.jpg')
, ('$2b$10$JdCg8yL3rRkkr.hhx1rjqOe30F9lhBlqA1sjYJW6ymzYExvQFHyjy', 'eve.holt', 'Eve', 'Holt', 'eve.holt@reqres.in', '6.jpg')
, ('$2b$10$JdCg8yL3rRkkr.hhx1rjqOe30F9lhBlqA1sjYJW6ymzYExvQFHyjy', 'charles.morris', 'Charles', 'Morris', 'charles.morris@reqres.in', '7.jpg')
, ('$2b$10$JdCg8yL3rRkkr.hhx1rjqOe30F9lhBlqA1sjYJW6ymzYExvQFHyjy', 'tracey.ramos', 'Tracey', 'Ramos', 'tracey.ramos@reqres.in', '8.jpg')

, ('$2b$10$JdCg8yL3rRkkr.hhx1rjqOe30F9lhBlqA1sjYJW6ymzYExvQFHyjy', 'michael.lawson', 'Michael', 'Lawson', 'michael.lawson@reqres.in', '9.jpg')
, ('$2b$10$JdCg8yL3rRkkr.hhx1rjqOe30F9lhBlqA1sjYJW6ymzYExvQFHyjy', 'lindsay.ferguson', 'Lindsay', 'Ferguson', 'lindsay.ferguson@reqres.in', '10.jpg')
, ('$2b$10$JdCg8yL3rRkkr.hhx1rjqOe30F9lhBlqA1sjYJW6ymzYExvQFHyjy', 'tobias.funke', 'Funke', 'Ferguson', 'tobias.funke@reqres.in', '11.jpg')
, ('$2b$10$JdCg8yL3rRkkr.hhx1rjqOe30F9lhBlqA1sjYJW6ymzYExvQFHyjy', 'byron.fields', 'Byron', 'Fields', 'byron.fields@reqres.in', '12.jpg')
, ('$2b$10$JdCg8yL3rRkkr.hhx1rjqOe30F9lhBlqA1sjYJW6ymzYExvQFHyjy', 'george.edwars', 'George', 'Edwards', 'george.edwards@reqres.in', '13.jpg')
, ('$2b$10$JdCg8yL3rRkkr.hhx1rjqOe30F9lhBlqA1sjYJW6ymzYExvQFHyjy', 'rachel.howell', 'Rachel', 'Howell', 'rachel.howell@reqres.in', '14.jpg')
;

COMMIT;
