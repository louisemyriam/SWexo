/*
 * Inicializamos el JS cuando se ha terminado de procesar todo el HTML de la página.
 *
 * Al incluir <script> al final de la página podríamos invocar simplemente a init().
 */
document.addEventListener('DOMContentLoaded', init);

/**
 * Inicializa la página
 */
function init() {
    const formRegistro = document.forms.namedItem('registro');
    formRegistro.addEventListener('submit', registroSubmit);

    const email = formRegistro.elements.namedItem('email');
    //email.addEventListener('change', compruebaEmail);
    email.addEventListener('input', compruebaEmail);

    const username = formRegistro.elements.namedItem('username');

    // username.addEventListener('change', usernameDisponible);
    username.addEventListener('input', usernameDisponible);
}

/**
 * 
 * @param {SubmitEvent} e 
 */
async function registroSubmit(e){
    // No se envía el formulario manualmente
    e.preventDefault();
    const formRegistro = e.target;
    try {
        const formData = new FormData(formRegistro);
        const response = await postData('/usuarios/registro', formData);
        window.location.assign('/usuarios/home');
    } catch (err) {
        if (err instanceof ResponseError) {
            switch(err.response.status) {
                case 400:
                    await displayErrores(err.response);
                    break;
            }
        }
        console.error(`Error: `, err);
    } 
}

async function displayErrores(response) {
    const { errores } = await response.json();
    const formRegistro = document.forms.namedItem('registro');
    for(const input of formRegistro.elements) {
        if (input.name == undefined || input.name === '') continue;
        const feedback = formRegistro.querySelector(`*[name="${input.name}"] ~ span.error`);
        if (feedback == undefined) continue;

        feedback.textContent = '';

        const error = errores[input.name];
        if (error) {
            feedback.textContent = error.msg;
        }
    }
}

function compruebaEmail(e) {
    const email = e.target;
    const icono = document.getElementById("icono-email");
    const mensaje = document.getElementById("mensaje-error");

    if (correoValidoUCM(email.value)) {
        email.setCustomValidity('');
    } else {
        email.setCustomValidity("El correo debe ser válido y acabar por @ucm.es");
    }

    // validación html5, porque el campo es <input type="email" ...>
    // https://developer.mozilla.org/en-US/docs/Web/API/HTMLInputElement/checkValidity
    // se asigna la pseudoclase :invalid
    const esCorreoValido = email.checkValidity();
    if (esCorreoValido) {
        // el correo es válido y acaba por @ucm.es
        icono.textContent = "✔";
        icono.style.color = "green";
        mensaje.style.display = "none";
        // <-- aquí pongo la marca apropiada, y quito (si la hay) la otra
        // ✔
    } else {			
        // correo invalido: ponemos una marca e indicamos al usuario que no es valido
        icono.textContent = "⚠";
        icono.style.color = "red";
        mensaje.style.display = "inline";

        // <-- aquí pongo la marca apropiada, y quito (si la hay) la otra
        // ⚠
    }
    // Muestra el mensaje de validación
    email.reportValidity();
}

function correoValidoUCM(correo) {
    return correo.endsWith("@ucm.es");
}

async function usernameDisponible(e) {
    const username = e.target;
    try {
        username.setCustomValidity('');
        const feedback = username.form.querySelector(`*[name="${username.name}"] ~ .feedback`);
        feedback.textContent = '';
        if (username.value === '') return;

        const response = await postJson('/api/usuarios/disponible', {
            username: username.value
        });
        const jsonData = await response.json();
        const estaDisponible = JSON.parse(jsonData);

        // Coloca tu código aquí
    } catch (err) {
        console.error(`Error: `, err);
    }
}