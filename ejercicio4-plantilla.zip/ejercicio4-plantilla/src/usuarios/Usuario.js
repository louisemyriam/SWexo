
import bcrypt from "bcryptjs";
import { ErrorDatos } from "../db.js";
import { join } from "node:path";
import { rm } from "node:fs";

export const RolesEnum = Object.freeze({
    USUARIO: 'U',
    ADMIN: 'A'
});

export class Usuario {
    static #getByUsernameStmt = null;
    static #insertStmt = null;
    static #updateStmt = null;
    static #listUsuarios = null;
    static #countUsuarios = null;
    static #checkUsername = null;

    static initStatements(db) {
        if (this.#getByUsernameStmt !== null) return;

        this.#getByUsernameStmt = db.prepare('SELECT * FROM Usuarios WHERE username = @username');
        this.#insertStmt = db.prepare('INSERT INTO Usuarios(username, password, rol, nombre, apellidos, email, avatar) VALUES (@username, @password, @rol, @nombre, @apellidos, @email, @avatar)');
        this.#updateStmt = db.prepare('UPDATE Usuarios SET username = @username, password = @password, rol = @rol, nombre = @nombre, apellidos = @apellidos, email = @email, avatar = @avatar WHERE id = @id');
        this.#listUsuarios = db.prepare('SELECT * FROM Usuarios ORDER BY id LIMIT @size OFFSET @offset');
        this.#countUsuarios = db.prepare('SELECT COUNT(*) AS numUsuarios FROM Usuarios').pluck();
        this.#checkUsername = db.prepare('SELECT 1 FROM Usuarios WHERE username = @username').pluck();
    }

    static getUsuarioByUsername(username) {
        const usuario = this.#getByUsernameStmt.get({ username });
        if (usuario === undefined) throw new UsuarioNoEncontrado(username);

        const { password, rol, nombre, apellidos, email, avatar, id } = usuario;

        return new Usuario(username, password, nombre, apellidos, email, avatar, rol, id);
    }

    static listUsuarios(pagina, size = 6) {
        const arrayUsuarios = this.#listUsuarios.all({ offset: pagina * size, size });
        const usuarios = [];
        for(const rawUsuario of arrayUsuarios) {
            const { username, password, rol, nombre, apellidos, email, avatar, id } = rawUsuario;
            const usuario = new Usuario(username, password, nombre, apellidos, email, avatar, rol, id);
            usuarios.push(usuario);
        }

        return usuarios;
    }

    static existeUsername(username) {
        const usuarioExiste = this.#checkUsername.get({ username });
        return usuarioExiste === 1;
    }

    static countUsuarios() {
        const numUsuarios = this.#countUsuarios.get();
        return numUsuarios;
    }

    static #insert(usuario) {
        let result = null;
        try {
            const username = usuario.#username;
            const password = usuario.#password;
            const nombre = usuario.nombre;
            const apellidos = usuario.apellidos;
            const email = usuario.email;
            const rol = usuario.rol;
            const avatar = usuario.#avatar;
            const datos = {username, password, rol, nombre, apellidos, email, avatar};

            result = this.#insertStmt.run(datos);

            usuario.#id = result.lastInsertRowid;
        } catch(e) { // SqliteError: https://github.com/WiseLibs/better-sqlite3/blob/master/docs/api.md#class-sqliteerror
            if (e.code === 'SQLITE_CONSTRAINT_UNIQUE') {
                throw new UsuarioYaExiste(usuario.#username);
            }
            throw new ErrorDatos('No se ha insertado el usuario', { cause: e });
        }
        return usuario;
    }

    static #update(usuario) {
        const id = usuario.#id;
        const username = usuario.#username;
        const password = usuario.#password;
        const nombre = usuario.nombre;
        const apellidos = usuario.apellidos;
        const email = usuario.email;
        const rol = usuario.rol;
        const avatar = usuario.#avatar;
        const datos = {username, password, nombre, apellidos, email, rol, avatar, id};

        const result = this.#updateStmt.run(datos);
        if (result.changes === 0) throw new UsuarioNoEncontrado(username);

        return usuario;
    }

    static async login(username, password) {
        let usuario = null;
        try {
            usuario = this.getUsuarioByUsername(username);
        } catch (e) {
            throw new UsuarioOPasswordNoValido(username, { cause: e });
        }

        const passwordMatch = await bcrypt.compare(password, usuario.#password);
        if ( ! passwordMatch ) throw new UsuarioOPasswordNoValido(username);

        return usuario;
    }

    static async creaUsuario(username, password, nombre, apellidos, email) {
        const usuario = new Usuario(username, password, nombre, apellidos, email);
        await usuario.cambiaPassword(password);
        usuario.persist();
        return usuario;
    }

    #id;
    #username;
    #password;
    rol;
    nombre;
    apellidos;
    email;
    #avatar;

    constructor(username, password, nombre, apellidos, email, avatar = null, rol = RolesEnum.USUARIO, id = null) {
        this.#username = username;
        this.#password = password;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.email = email;
        this.#avatar = avatar;
        this.rol = rol;
        this.#id = id;
    }

    get id() {
        return this.#id;
    }

    async cambiaPassword(nuevoPassword) {
        /* Nota: este método reemplaza set password() { } ya 
        que no se pueden hacer asíncronos los métodos get / set
        */
        this.#password = bcrypt.hashSync(nuevoPassword);    
    }

    get username() {
        return this.#username;
    }

    get avatar() {
        let avatar = this.#avatar;
        if (avatar == null) avatar = `default.svg`;
        return `/avatares/${avatar}`;
    }

    async cambiaAvatar(nuevoAvatarPath, tipoMime) {
        if (this.#avatar != null) {
            const path = join(config.avatares, this.#avatar);
            await rm(this.#avatar);
            this.#avatar = null;
        }

        if (nuevoAvatarPath == null || tipoMime == null) return this.avatar();

        const mimeType = tipoMime.match(/^(?<tipo>[^/]+)\/(?<subtipo>.+)$/)?.groups;
        const tipo = mimeType?.tipo;
        const subtipo = mimeType?.subtipo;
        if (tipo == null || subtipo == null || tipo !== 'image') throw new Error(`Tipo incorrecto, se espera image/*: ${tipoMime}`);
    
        const nombre = `${this.#id}.${subtipo}`;
        const path = join(config.avatares, nombre);
        await rename(nuevoAvatarPath, path);
        this.#avatar = nombre;

        return this.avatar();
    }

    persist() {
        if (this.#id === null) return Usuario.#insert(this);
        return Usuario.#update(this);
    }
}

export class UsuarioNoEncontrado extends Error {
    /**
     * 
     * @param {string} username 
     * @param {ErrorOptions} [options]
     */
    constructor(username, options) {
        super(`Usuario no encontrado: ${username}`, options);
        this.name = 'UsuarioNoEncontrado';
    }
}

export class UsuarioOPasswordNoValido extends Error {
    /**
     * 
     * @param {string} username 
     * @param {ErrorOptions} [options]
     */
    constructor(username, options) {
        super(`Usuario o password no válido: ${username}`, options);
        this.name = 'UsuarioOPasswordNoValido';
    }
}


export class UsuarioYaExiste extends Error {
    /**
     * 
     * @param {string} username 
     * @param {ErrorOptions} [options]
     */
    constructor(username, options) {
        super(`Usuario ya existe: ${username}`, options);
        this.name = 'UsuarioYaExiste';
    }
}