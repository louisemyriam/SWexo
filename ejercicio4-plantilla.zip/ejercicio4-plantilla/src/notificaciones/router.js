import express from 'express';
import { param } from 'express-validator';
import { autenticado, tieneRol } from '../middleware/auth.js';
import asyncHandler from 'express-async-handler';
import { listNotificaciones } from './controllers.js';

const notificacionesRouter = express.Router();

notificacionesRouter.use(autenticado('/usuarios/login'));

notificacionesRouter.get('/:categoria'
    , param('categoria', 'Falta categoria')
    , asyncHandler(listNotificaciones));

export default notificacionesRouter;