BEGIN TRANSACTION;
-- password: userpass
INSERT INTO "Usuarios" ("id","username","password","rol","nombre") VALUES (1,'user','$2b$10$JdCg8yL3rRkkr.hhx1rjqOe30F9lhBlqA1sjYJW6ymzYExvQFHyjy','U','Usuario');
-- password: adminpass
INSERT INTO "Usuarios" ("id","username","password","rol","nombre") VALUES (2,'admin','$2b$10$Htah5iG9eKj8ItIItpzK6uvny3c5/QjdZaLwwmFy32RPrfVspNgYS','A','Administrador');
COMMIT;
