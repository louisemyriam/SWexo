import 'dotenv/config';
import { join, dirname } from 'node:path';

const isProduction = process.env.NODE_ENV === 'production';

// Define defaults
const DEFAULT_PORT = 3000;
const DEFAULT_SESSION_SECRET = 'no muy secreto';

// Validate the port
function isValidPort(value) {
    const num = parseInt(value, 10);
    return !isNaN(num) && num >= 1 && num <= 65535;
}
// ca verifie que c'est bien un num et pas des lettres et que c dans le right range of ports?

// Get port from env or fallback
const portEnv = process.env.APP_PORT;
const finalPort = isValidPort(portEnv) ? parseInt(portEnv, 10) : DEFAULT_PORT;
/* meme chose:
if (isValidPort(portEnv)) {
  finalPort = parseInt(portEnv, 10);
} else {
  finalPort = DEFAULT_PORT;
}
*/

// Get session secret from env or fallback
const sessionSecret = process.env.APP_SESSION_SECRET || DEFAULT_SESSION_SECRET;

export const config = {
    port: finalPort,

    recursos: join(dirname(import.meta.dirname), 'static'),
    vistas: join(dirname(import.meta.dirname), 'vistas'),

    session: {
        resave: false,
        saveUninitialized: true,
        secret: sessionSecret
    },
    isProduction,
    logs: join(dirname(import.meta.dirname), 'logs'),
    logger: {
        level: process.env.APP_LOG_LEVEL ?? (!isProduction ? 'debug' : 'info'),
        http: (pino) => ({
            logger: pino,
            autoLogging: !isProduction,
            useLevel: 'trace'
        })
    }
};
