import express from "express";

const contenidoRouter = express.Router();

contenidoRouter.get("/normal", (req, res) => {
  let contenido = "paginas/noPermisos";
  if (req.session && req.session.login) {
    contenido = "paginas/normal";
  }
  res.render("pagina", {
    contenido,
    session: req.session,
  });
});

contenidoRouter.get("/admin", (req, res) => {
  if (req.session && req.session.esAdmin) {
    res.render("paginas/admin", { session: req.session });
  } else {
    res.render("paginas/noPermisos", { session: req.session });
    res.status(403).send("No tienes permismos. Contantacta al administrador");
  }
});

export default contenidoRouter;