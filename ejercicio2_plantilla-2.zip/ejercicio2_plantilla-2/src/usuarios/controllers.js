import { body, validationResult } from "express-validator";

export function viewLogin(req, res) {
  res.render("pagina", {
    contenido: "paginas/login", // Use the login page as content
    session: req.session, // Pass session data
    error: null, // Pass error if any
  });
}


export function doLogin(req, res) {
  body("username").escape(); // Se asegura que eliminar caracteres problemáticos
  body("password").escape(); // Se asegura que eliminar caracteres problemáticos
  // TODO: tu código aquí

  const { username, password } = req.body;

  if (users[username] && users[username].password === password) {
    req.session.login = true;
    req.session.name = username;
    req.session.administrator = users[username].role === "admin";
    return res.redirect("/contenido/normal");
  } else {
    return res.render("paginas/login.ejs", {
      error: "Usuario o contraseña incorrectos",
    });
  }
}

export function viewContenido(req, res) {
  if (req.session.login) {
    res.render("paginas/contenido.ejs", { usuario: req.session.name });
  } else {
    res.render("paginas/noPermisos.ejs");
  }
}

export function viewContenidoAdmin(req, res) {
  if (req.session.administrator) {
    res.render("paginas/contenidoAdmin.ejs", { usuario: req.session.name });
  } else {
    res.render("paginas/noPermisos.ejs");
  }
}

export function doLogout(req, res, next) {
  // TODO: https://expressjs.com/en/resources/middleware/session.html
  req.session.destroy((err) => {
    //elimina sesión del servidor
    if (err) {
      return next(err); //si hay error
    }
    res.clearCookie("connect.sid", { path: "/" }); //elimina cookie

    res.send("Has cerrado sesión");
  });
}