#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <err.h>

/** Loads a string from a file.
 *
 * file: pointer to the FILE descriptor
 *
 * The loadstr() function must allocate memory from the heap to store
 * the contents of the string read from the FILE.
 * Once the string has been properly built in memory, the function returns
 * the starting address of the string (pointer returned by malloc())
 *
 * Returns: !=NULL if success, NULL if error
 */
char *loadstr(FILE *file) {
    char c;           // Temporary variable to store the character read
    int length = 0;   // Length of the string to be read

    // Read character by character until the null terminator '\0' is found
    while (fread(&c, 1, 1, file) != 0) {
        
        length++; // Increment length for each character read

        if (c == '\0') // Exit the loop if the null terminator is found
            break;
    }

    // If nothing was read or EOF was reached without finding a valid string
    if (length == 0 || c == EOF) {
        return NULL; 
    }

    // Rewind the file pointer to the start of the string
    fseek(file, -length, SEEK_CUR);

	/* 
	fseek(FILE *file, long offset, int origin);

	SEEK_SET: Starts from the beginning of the file.
	SEEK_CUR: Starts from the current position of the file pointer.
	SEEK_END: Starts from the end of the file.
	 */

    // Allocate memory for the string to be read
    char *buffer = (char *)malloc((length));

    // Read the entire string from the file and store it in the buffer
    fread(buffer, 1, length, file);

    return buffer; 
}

int main(int argc, char *argv[]) {

    FILE* file = NULL; // File pointer for file operations
    char *c;           // Pointer for the strings read

    // Verify that a file name has been provided as an argument
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <file_name>\n", argv[0]);
        exit(1);  // Exit if no file is provided
    }

    // Open the file in read mode
    if ((file = fopen(argv[1], "r")) == NULL)  // If fopen returns NULL, an error occurred
        err(2, "The input file %s could not be opened", argv[1]);

    // Read all strings in the file until no more strings are found (`loadstr` returns NULL)
    while ((c = loadstr(file)) != NULL) {
       
        printf("%s\n", c); // Print the string
        free(c);  // Free the memory allocated for the string after use
    }

    // Close the file after completing the read
    fclose(file);

    return 0;
}

/*
to test:
./read_strings <testfile>

*/