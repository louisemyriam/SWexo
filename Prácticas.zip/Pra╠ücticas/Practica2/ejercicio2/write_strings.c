#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <err.h>

int main(int argc, char* argv[])
{ 

	FILE *file;
	
	if (argc < 3) { 
		fprintf(stderr,"Usage: %s <file_name> <string1><string2>..\n",argv[0]);
		exit(1);
	}
	//open the file for writing mode
	if ((file = fopen(argv[1], "w")) == NULL){
		err(2,"The input file %s could not be opened",argv[1]);
	}

// size_t fwrite(const void *ptr, size_t size, size_t count, FILE *stream);
			/* ptr = This is a pointer to the data that you want to write. It points to the starting address of the block of memory that contains the data.
			size= This specifies the size in bytes of each element you want to write ,eg:if you're writing characters, you would typically use sizeof(char) which is 1
			count = This is the number of elements you want to write. For example, if you want to write a string of characters, this would be the length of the string
			stream= This is a pointer to a FILE object that identifies the output stream (the file) where the data will be written. 
			*/

	// on cherche la longueur des strings
	for (int i =2 ; i<argc; i++){
		size_t len = strlen(argv[i]);
		//strlen calcule la long de un string 


	//on ecrit les strings au fichier
		if (fwrite (argv[i],sizeof(char), len,file)!=len ){
			fclose(file);
			err(3,"fwrite() failed to write string '%s'" ,argv[i]);
		}
	
	//
		if (fwrite("\0", sizeof(char),1,file)!=1){
			fclose(file);
			err(4,"fwrite failed to write \\0 ");
		}
	}
	fclose (file);
	return 0;
}

/*
   	┌──────────────┬───────────────────────────────┐
	│ fopen() mode │ open() flags                  │
	├──────────────┼───────────────────────────────┤
	│      r       │ O_RDONLY                      │
	├──────────────┼───────────────────────────────┤
	│      w       │ O_WRONLY | O_CREAT | O_TRUNC  │
	├──────────────┼───────────────────────────────┤
	│      a       │ O_WRONLY | O_CREAT | O_APPEND │
	├──────────────┼───────────────────────────────┤
	│      r+      │ O_RDWR                        │
	├──────────────┼───────────────────────────────┤
	│      w+      │ O_RDWR | O_CREAT | O_TRUNC    │
	├──────────────┼───────────────────────────────┤
	│      a+      │ O_RDWR | O_CREAT | O_APPEND   │
	└──────────────┴───────────────────────────────┘
*/


/* 

to test:

./write_strings <file_nam(existent or not)> <string1><string2>..


*/