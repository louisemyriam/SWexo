#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h> /* for getopt() */
#include "defs.h"

/* Assume lines in the text file are no larger than 100 chars */
#define MAXLEN_LINE_FILE 100  // Maximum length for each line in the text file



// Function to load a null-terminated string from a binary file (Used only in Part C)
char *loadstr(FILE *file) {
    char c;
    int length = 0;
    long startPos = ftell(file);  // Save the initial position in the file

    // Count characters until reaching the null terminator
    while (fread(&c, sizeof(char), 1, file) == 1) {
        if (c == '\0') {
            break;
        }
        length++;
    }

    // Check for read errors or EOF
    if (ferror(file) || feof(file)) {
        return NULL;
    }

    // Allocate memory for the string (including null terminator)
    char *str = (char *)malloc((length + 1) * sizeof(char));
    if (str == NULL) {
        return NULL;
    }

    fseek(file, startPos, SEEK_SET); // Reset to start position
    fread(str, sizeof(char), length + 1, file);
    return str;
}




// Part A: Print a text file
int print_text_file(char *path) {
    FILE *file = NULL;  // File pointer to handle the input file
    char line[MAXLEN_LINE_FILE + 1];  // Buffer to hold each line from the file
    char *lineptr, *token;  // Pointers to process the line and extract tokens
    int num_entries;  // The number of student entries
    student_t cur_entry;  // Structure to store the current student data
    token_id_t token_id;  // Keeps track of which part of the student record we are parsing

    // Open the input file for reading
    if ((file = fopen(path, "r")) == NULL) {
        fprintf(stderr, "%s could not be opened: ", path);
        perror(NULL);  // Prints the system error if file can't be opened
        return 1;  // Return error code
    }

    // Read the first line to get the number of entries
    if (fgets(line, sizeof(line), file) == NULL) {
        fprintf(stderr, "Error reading number of entries.\n");
        fclose(file);
        return 1;  // Return error code
    }
    num_entries = atoi(line);  // Convert the line (string) to an integer

    // Process each student entry
    for (int i = 0; i < num_entries; i++) {
        if (fgets(line, sizeof(line), file) == NULL) {
            fprintf(stderr, "Error reading line %d\n", i);
            fclose(file);
            return 1;  // Return error code
        }

        lineptr = line;  // Set pointer to start of the line
        token_id = STUDENT_ID_IDX;  // Start processing student ID

        // Split the line into tokens and assign values to the student structure
        while ((token = strsep(&lineptr, ":")) != NULL) {
            switch (token_id) {
            case STUDENT_ID_IDX:
                cur_entry.student_id = atoi(token);  // Convert student ID from string to integer
                break;
            case NIF_IDX:
                strncpy(cur_entry.NIF, token, MAX_CHARS_NIF);  // Copy NIF, ensure no overflow
                cur_entry.NIF[MAX_CHARS_NIF] = '\0';  // Null-terminate the NIF
                break;
            case FIRST_NAME_IDX:
                cur_entry.first_name = strdup(token);  // Duplicate first name
                break;
            case LAST_NAME_IDX:
                cur_entry.last_name = strdup(token);  // Duplicate last name
                break;
            default:
                break;  // Ignore other tokens
            }
            token_id++;  // Move to the next token
        }

        // Check if the correct number of fields were parsed
        if (token_id != NR_FIELDS_STUDENT) {
            fprintf(stderr, "Error parsing line %d\n", i);
            fclose(file);
            return 1;  // Return error code
        }

        // Print the parsed student information
        printf("[Entry #%d]\n\tstudent_id=%d\n\tNIF=%s\n\tfirst_name=%s\n\tlast_name=%s\n",
               i, cur_entry.student_id, cur_entry.NIF, cur_entry.first_name, cur_entry.last_name);

        free(cur_entry.first_name);  // Free allocated memory for first name
        free(cur_entry.last_name);  // Free allocated memory for last name
    }

    fclose(file);  // Close the file after processing
    return 0;  // Return success
}

// Part B: Write a binary file
int write_binary_file(char *input_file, char *output_file) {
    FILE *inputfile = NULL, *outputfile = NULL;  // File pointers for input and output
    char line[MAXLEN_LINE_FILE + 1];  // Buffer to hold each line
    char *lineptr, *token;  // Pointers to process the line and extract tokens
    int num_entries;  // Number of student entries
    token_id_t token_id;  // Keeps track of the current field being parsed

    // Open input file for reading and output file for writing in binary mode
    if ((inputfile = fopen(input_file, "r")) == NULL) {
        fprintf(stderr, "%s could not be opened: ", input_file);
        perror(NULL);
        return 1;  // Return error code
    }
    if ((outputfile = fopen(output_file, "wb")) == NULL) {
        fprintf(stderr, "%s could not be opened: ", output_file);
        perror(NULL);
        fclose(inputfile);
        return 1;  // Return error code
    }

    // Read the number of entries from the input file
    if (fgets(line, sizeof(line), inputfile) == NULL) {
        fprintf(stderr, "Error reading number of entries.\n");
        fclose(inputfile);
        fclose(outputfile);
        return 1;  // Return error code
    }
    num_entries = atoi(line);  // Convert number of entries to integer
    fwrite(&num_entries, sizeof(int), 1, outputfile);  // Write number of entries to binary file

    // Process each student entry
    for (int i = 0; i < num_entries; i++) {
        if (fgets(line, sizeof(line), inputfile) == NULL) {
            fprintf(stderr, "Error reading line %d\n", i);
            fclose(inputfile);
            fclose(outputfile);
            return 1;  // Return error code
        }

        lineptr = line;  // Set pointer to start of the line
        token_id = STUDENT_ID_IDX;  // Start processing student ID
        student_t cur_entry;  // Structure to hold student data

        // Split the line into tokens and assign values to the student structure
        while ((token = strsep(&lineptr, ":")) != NULL) {
            switch (token_id) {
            case STUDENT_ID_IDX:
                cur_entry.student_id = atoi(token);  // Convert student ID from string to integer
                break;
            case NIF_IDX:
                strncpy(cur_entry.NIF, token, MAX_CHARS_NIF);  // Copy NIF, ensure no overflow
                cur_entry.NIF[MAX_CHARS_NIF] = '\0';  // Null-terminate the NIF
                break;
            case FIRST_NAME_IDX:
                cur_entry.first_name = strdup(token);  // Duplicate first name
                break;
            case LAST_NAME_IDX:
                cur_entry.last_name = strdup(token);  // Duplicate last name
                break;
            default:
                break;  // Ignore other tokens
            }
            token_id++;  // Move to the next token
        }

        // Write the student data to the binary output file
        fwrite(&cur_entry.student_id, sizeof(int), 1, outputfile);
        fwrite(cur_entry.NIF, sizeof(char), MAX_CHARS_NIF + 1, outputfile);
        fwrite(cur_entry.first_name, sizeof(char), strlen(cur_entry.first_name) + 1, outputfile);
        fwrite(cur_entry.last_name, sizeof(char), strlen(cur_entry.last_name) + 1, outputfile);

        free(cur_entry.first_name);  // Free allocated memory for first name
        free(cur_entry.last_name);  // Free allocated memory for last name
    }

    fclose(inputfile);  // Close input file
    fclose(outputfile);  // Close output file
    return 0;  // Return success
}

//Part C
// Function to print a binary file
int print_binary_file(char *path) {
    FILE *f;
    int num_records;
    int student_id;
    char *NIF, *first_name, *last_name;
    int i;

    f = fopen(path, "rb");
    if (!f) {
        fprintf(stderr, "Could not open binary file %s\n", path);
        return EXIT_FAILURE;
    }

    // Read the number of records
    if (fread(&num_records, sizeof(int), 1, f) != 1) {
        fprintf(stderr, "Failed to read number of records from binary file\n");
        fclose(f);
        return EXIT_FAILURE;
    }

    // Read each record and display it
    for (i = 0; i < num_records; i++) {
        // Read student_id
        if (fread(&student_id, sizeof(int), 1, f) != 1) {
            fprintf(stderr, "Failed to read student ID\n");
            fclose(f);
            return EXIT_FAILURE;
        }

        // Read NIF, first_name, and last_name using loadstr()
        NIF = loadstr(f);
        first_name = loadstr(f);
        last_name = loadstr(f);

        if (NIF == NULL || first_name == NULL || last_name == NULL) {
            fprintf(stderr, "Error reading string from file.\n");
            fclose(f);
            return EXIT_FAILURE;
        }

        // Print the record
        printf("[Entry #%d]\n\tstudent_id=%d\n\tNIF=%s\n\tfirst_name=%s\n\tlast_name=%s\n",
               i, student_id, NIF, first_name, last_name);

        // Free allocated memory
        free(NIF);
        free(first_name);
        free(last_name);
    }

    fclose(f);
    return EXIT_SUCCESS;
}


int main(int argc, char *argv[]) {
    int ret_code, opt;
    struct options options;

    options.input_file = NULL;
    options.output_file = NULL;
    options.action = NONE_ACT;
    ret_code = 0;

    // Process command line arguments
    while ((opt = getopt(argc, argv, "hi:po:b")) != -1) {
        switch (opt) {
        case 'h':  // Print usage information
            fprintf(stderr, "Usage: %s [ -h | -p | -o file | -o <output_file> | -b ]\n", argv[0]);
            exit(EXIT_SUCCESS);  // Exit after printing help
        case 'i':  // Set input file path
            options.input_file = optarg;
            break;
        case 'p':  // Action to print the text file
            options.action = PRINT_TEXT_ACT;
            break;
        case 'o':  // Set output file path and action to write binary
            options.output_file = optarg;
            options.action = WRITE_BINARY_ACT;
            break;
        case 'b':  // Action to print the binary file
            options.action = PRINT_BINARY_ACT;
            break;
        default:
            exit(EXIT_FAILURE);  // Exit with failure if an invalid option is provided
        }
    }

    // Ensure an input file is provided
    if (options.input_file == NULL) {
        fprintf(stderr, "Must specify one record file as an argument of -i\n");
        exit(EXIT_FAILURE);
    }

    // Execute the chosen action
    switch (options.action) {
    case NONE_ACT:
        fprintf(stderr, "Must indicate one of the following options: -p, -o, -b \n");
        ret_code = EXIT_FAILURE;
        break;
    case PRINT_TEXT_ACT:
        ret_code = print_text_file(options.input_file);  // Print the text file
        break;
    case WRITE_BINARY_ACT:
        ret_code = write_binary_file(options.input_file, options.output_file);  // Write to binary file
        break;
    case PRINT_BINARY_ACT:
        ret_code = print_binary_file(options.input_file);  // Print the binary file
        break;
    default:
        break;
    }

    exit(ret_code);  // Exit with the appropriate return code
}

/*

to test :

Part A:
./student-records -i students-db.txt -p

Part B:
./student-records -i students-db.txt -o students-db.bin

Part C:
./student-records -i students-db.bin -b


*/