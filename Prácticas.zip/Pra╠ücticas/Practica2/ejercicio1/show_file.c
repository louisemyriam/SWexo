#include <stdio.h>
#include <stdlib.h>
#include <err.h>

/* Main function that reads a file byte by byte and writes the content to stdout */
int main(int argc, char* argv[]) {
	FILE* file = NULL; // File pointer to handle the file operations
	unsigned char buffer; // Buffer to store one byte at a time

	//check if there there isn't enough arg
	if (argc != 2) {
		fprintf(stderr, "Usage: %s <file_name>\n", argv[0]); 
		exit(1); 
	}

	/* Open the file for reading */
	if ((file = fopen(argv[1], "r")) == NULL) {
		// If the file cannot be opened, print an error message and exit
		err(2, "The input file %s could not be opened", argv[1]);
	}
	//  avec getc y putc

	/* Read file byte by byte */
	/* while ((c = getc(file)) != EOF) { // getc: reads the file and returns characters as int or EOF
		// Print byte to stdout 
		ret = putc((unsigned char) c, stdout); // putc: converts the read character to an unsigned char and prints it to the standard output (stdout)

		if (ret == EOF) { // If writing with putc() fails (returns EOF)
			fclose(file); // Always close the file
			err(3, "putc() failed!!"); // Display an error message
		}
	} */
	
	// avec fread et fwrite

	// Reading file content using fread and writing it to stdout using fwrite
	while ((fread(&buffer, 1, 1, file)) != 0) { 
		// fread reads 1 byte from the file into the buffer
		// Returns 0 if the end of the file is reached or an error occurs

		if (fwrite(&buffer, 1, 1, stdout) == 0) { 
			// fwrite writes 1 byte from the buffer to stdout
			// If it fails (returns 0), an error is raised
			fclose(file); // Ensure the file is closed before exiting
			err(3, "fwrite() failed!!"); // Print an error message and exit
		}
	}

	fclose(file); // Close the file after all operations are complete
	return 0; // Return 0 to indicate successful execution
}

/*Example: If you want to read 10 blocks of 1 byte each from a file, you would write something like this:

char buffer[10];            // A buffer to store the data
fread(buffer, 1, 10, file);  // Read 10 bytes from the file into the buffer
Here, buffer is where we store what we read, and we’re saying we want to read 10 elements of 1 byte each from the file.
*/






/*to test:
./show_file ejtest.txt
*/