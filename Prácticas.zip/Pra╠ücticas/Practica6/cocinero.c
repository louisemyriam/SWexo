#include <stdio.h>      // For printf
#include <stdlib.h>     // For functions like exit and rand
#include <signal.h>     // For signal handling (sigaction, SIGINT)
#include <unistd.h>     // For sleep
#include <fcntl.h>      // For file creation flags (O_CREAT, O_RDWR)
#include <sys/mman.h>   // For shared memory functions (shm_open, mmap)
#include <sys/stat.h>   // For file permissions
#include <semaphore.h>  // For POSIX semaphores
#include <time.h>       // For rand and srand (random number generation)
#include <errno.h>      // For error handling

// Define a name for the shared memory
#define SHM_NAME "/shared_pot" // Shared memory segment name

#define SHM_SIZE sizeof(int)              // Size of the shared memory segment (an integer in this case)

// Semaphore names definition
#define SEM_POT "/sem_pot"         // Semaphore to control access to the pot
#define SEM_EMPTY "/sem_empty"     // Semaphore to indicate that the pot is empty to the cook
#define SEM_FULL "/sem_full"       // Signals the savages that servings are available in the pot.

#define M 10

int finish = 0;  // Flag to indicate when to terminate the program

// Pointer to the shared memory
int *pot = NULL;  // This will hold the address of the shared memory

// Semaphore pointers
sem_t *sem_pot = NULL;
sem_t *sem_empty = NULL;
sem_t *sem_full = NULL;

// Fills the pot with the specified amount of servings
void putServingsInPot(int servings)
{   
    // Correcting the printf to show the value of *pot
    printf("Pot has: %d\n", *pot);

    // Refill the pot with M servings
    if (pot) { // Check if shared memory is available
        *pot = servings;
        printf("Cook: The pot has been refilled with %d servings.\n", servings);
        sem_post(sem_full);  // Notify the wilds that the pot has been refilled
    } else {
        fprintf(stderr, "Error: Shared memory is not initialized.\n");
    }
}

// Main logic of the cook: waits for the pot to be empty and refills it
void cook(void)
{
    // Loop continues until receiving the SIGINT signal
    while (!finish) {
       
        // -----------------------
        // Semaphore synchronization process:
        // When sem_wait(sem_empty) is called:
        // 1. If the semaphore value is > 0, the process can enter the critical section.
        // 2. If the semaphore value is 0, the process waits until another process releases it.
        //
        // Initial value of sem_empty = 0.
        // Value of sem_empty after sem_wait: 0 -> -1, allowing mutual exclusion.
        // -----------------------
        sem_wait(sem_empty);

        if (!finish) { // If termination signal hasn't been received
            sem_wait(sem_pot); // Acquire the semaphore to ensure mutual exclusion
            if (*pot == 0){
                putServingsInPot(M);
            }
            sem_post(sem_pot); // Release the semaphore after modifying the pot
        }
        
        // sem_post(sem_full); // Already done by putServingsInPot()

        printf("Cook: Refilling the pot with %d servings\n", M);  // Print when the cook is refilling the pot
    }
    printf("Cook: Ending the program.\n");  // Print when the cook ends the program
}

// Signal handler: executes when receiving SIGTERM or SIGINT
void handler(int signo)
{   
    if (signo == SIGINT || signo == SIGTERM){
        
        // --------------------------
        // Close and unlink semaphores and shared memory
        // --------------------------
        if (sem_pot) sem_close(sem_pot);
        if (sem_empty) sem_close(sem_empty);
        if (sem_full) sem_close(sem_full);

        sem_unlink(SEM_POT);
        sem_unlink(SEM_EMPTY);
        sem_unlink(SEM_FULL);

        // --------------------------
        // Free shared memory
        // --------------------------
        // `munmap` unmaps the shared memory from the process
        if (pot) munmap(pot, SHM_SIZE);

        // `shm_unlink` removes the shared memory object from the system
        shm_unlink(SHM_NAME);

        printf("Shared memory deleted. Program safely terminated.\n");

        // Set finish to 1 to indicate that the program should terminate
        finish = 1; 
    }
}

int main() {

    // Set up the signal handler
    struct sigaction sa;
    sa.sa_handler = handler;        // Assign the handler function
    sigemptyset(&sa.sa_mask);       // Clear the set of blocked signals
    sa.sa_flags = 0;                // No special flags

    // Set up the handler for SIGINT (Ctrl+C)
    if (sigaction(SIGINT, &sa, NULL) == -1) {
        perror("Error setting up the signal handler");
        exit(EXIT_FAILURE);
    }

    // Set up the handler for SIGTERM (when terminated by kill or some condition)
    if (sigaction(SIGTERM, &sa, NULL) == -1) {
        perror("Error setting up the signal handler");
        exit(EXIT_FAILURE);
    }

    // --------------------------
    // Remove any existing shared memory to avoid conflicts
    // --------------------------
    if (shm_unlink(SHM_NAME) == -1) {
        if (errno != ENOENT) { // Ignore the error if the object doesn't exist
            perror("Error removing existing shared memory");
            // Continue if the error is ENOENT (not found)
        }
    }

    // --------------------------
    // Create and initialize semaphores
    // --------------------------

    // Semaphore 'sem_pot': controls access to the pot
    // Initialized to 1, meaning the pot is available
    sem_pot = sem_open(SEM_POT, O_CREAT, 0644, 1);
    if (sem_pot == SEM_FAILED) {
        perror("Error creating 'pot' semaphore");
        exit(EXIT_FAILURE);
    }

    // Semaphore 'sem_empty': controls that the pot is empty
    // Initialized to 0, since initially there are M servings in the pot
    sem_empty = sem_open(SEM_EMPTY, O_CREAT, 0644, 0);
    if (sem_empty == SEM_FAILED) {
        perror("Error creating 'empty' semaphore");
        sem_unlink(SEM_POT);
        exit(EXIT_FAILURE);
    }

    // Semaphore 'sem_full': controls that the pot has been refilled
    // Initialized to 0, so the wilds wait until the cook refills the pot
    sem_full = sem_open(SEM_FULL, O_CREAT, 0644, 0);
    if (sem_full == SEM_FAILED) {
        perror("Error creating 'full' semaphore");
        sem_unlink(SEM_POT);
        sem_unlink(SEM_EMPTY);
        exit(EXIT_FAILURE);
    }

    // --------------------------
    // Create the shared memory
    // --------------------------
    // `shm_open` creates or opens a shared memory object
    // Arguments:
    // - SHM_NAME: Name of the object in the system, so it can be accessed by other processes.
    // - O_CREAT | O_RDWR: Create the object if it doesn't exist and open it in read/write mode.
    // - 0666: Read/write permissions for all users (rwxrwxrwx).
    int shm_fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0666);

    if (shm_fd == -1) {
        perror("Error creating shared memory");
        sem_unlink(SEM_POT);
        sem_unlink(SEM_EMPTY);
        sem_unlink(SEM_FULL);
        exit(EXIT_FAILURE);
    }

    // --------------------------
    // Set the size of the shared memory
    // --------------------------
    // `ftruncate` sets the size of the shared memory object
    // - Argument 1: File descriptor of the shared memory (`shm_fd`).
    // - Argument 2: Desired size for the memory (`SHM_SIZE`, here an integer).
    if (ftruncate(shm_fd, SHM_SIZE) == -1) {
        perror("Error setting the shared memory size");
        close(shm_fd);   // Close the descriptor before exiting
        shm_unlink(SHM_NAME);
        sem_unlink(SEM_POT);
        sem_unlink(SEM_EMPTY);
        sem_unlink(SEM_FULL);
        exit(EXIT_FAILURE);
    }

    // --------------------------
    // Map the shared memory into the process's address space
    // --------------------------
    // `mmap` maps the shared memory into the process's address space
    // - Argument 1 (NULL): Suggested memory address (NULL so the system can choose).
    // - Argument 2 (SHM_SIZE): Size of the mapping, here the size of an integer.
    // - Argument 3 (PROT_READ | PROT_WRITE): Mapping permissions (read and write).
    // - Argument 4 (MAP_SHARED): Changes in memory will be visible to other processes.
    // - Argument 5 (shm_fd): Shared memory file descriptor.
    // - Argument 6 (0): Offset (we don't use it here).
    pot = mmap(NULL, SHM_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    if (pot == MAP_FAILED) {
        perror("Error mapping shared memory");
        close(shm_fd);
        shm_unlink(SHM_NAME);
        sem_unlink(SEM_POT);
        sem_unlink(SEM_EMPTY);
        sem_unlink(SEM_FULL);
        exit(EXIT_FAILURE);
    }

    // --------------------------
    // Initialize the shared memory counter
    // --------------------------
    *pot = M; // Initialize the shared memory with M servings
    printf("Shared memory created and initialized with %d servings.\n", *pot);

    // Post the semaphore 'sem_full' as many times as there are initial servings, so the wilds can start.
    for (int i = 0; i < M; i++) {
        sem_post(sem_full);
    }

    cook();  // Execute the main cook logic

    // --------------------------
    // Clean up resources at the end (in case cook() exits without signals)
    // --------------------------
    if (!finish) { // If finish is not set to 1
        // Release semaphores and shared memory
        sem_close(sem_pot);
        sem_close(sem_empty);
        sem_close(sem_full);
        sem_unlink(SEM_POT);
        sem_unlink(SEM_EMPTY);
        sem_unlink(SEM_FULL);
        munmap(pot, SHM_SIZE);
        shm_unlink(SHM_NAME);
        printf("Resources successfully released. Program finished.\n");
    }

    return 0;  // Terminate the program successfully
}

/* Permissions explanation

0 6 6 4
- - ---
│ │ │ └─ Permissions for others (users who are neither the owner nor in the group)
│ │ └── Permissions for the file's group
│ └─── Permissions for the file's owner
└───── Special indicator (not always used here it's `0`).

Possible values for each digit
4 (read - r): Allows reading the file or listing the contents of the directory.
2 (write - w): Allows modifying the file or adding/removing files from a directory.
1 (execute - x): Allows executing a file as a program or accessing a directory.

Combinations:
0: No permissions.
1: Execute only.
2: Write only.
3: Write + execute.
4: Read only.
5: Read + execute.
6: Read + write.
7: Read + write + execute. */
