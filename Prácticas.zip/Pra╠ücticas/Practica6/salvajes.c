#include <stdio.h>      // For printf
#include <stdlib.h>     // For functions like exit and rand
#include <signal.h>     // For signal handling (sigaction, SIGINT)
#include <unistd.h>     // For sleep
#include <fcntl.h>      // For file creation flags (O_CREAT, O_RDWR)
#include <sys/mman.h>   // For shared memory functions (shm_open, mmap)
#include <sys/stat.h>   // For file permissions
#include <semaphore.h>  // For POSIX semaphores
#include <time.h>       // For rand and srand (random number generation)

#define SHM_NAME "/shared_pot" // Shared memory segment name
#define SHM_SIZE sizeof(int)   // Size of the shared memory segment (an integer in this case)

#define SEM_POT "/sem_pot"         // Semaphore to control access to the pot
#define SEM_EMPTY "/sem_empty"     // Semaphore to indicate to the cook that the pot is empty
#define SEM_FULL "/sem_full"       // Semaphore to indicate to the savages that the pot has been refilled

#define NUMITER 20  // Number of iterations for the savages to take servings

// Pointer to shared memory
int *pot = NULL;  // This will store the address of the shared memory

// Semaphore pointers
sem_t *sem_pot = NULL;
sem_t *sem_empty = NULL;
sem_t *sem_full = NULL;

// Simulate the savage eating
void eat(void)
{
    unsigned long id = (unsigned long) getpid();
    printf("Savage %lu eating\n", id);  // Print the savage's action of eating
    sleep(rand() % 5);  // Simulate the eating time with a random sleep
}

// Function to get servings from the pot
int getServingsFromPot(void)
{
    if (pot) { // Check if shared memory is available
        if (*pot > 0) {
            eat();  // Simulate the savage eating
            (*pot)--;  // Take one serving
            printf("Remaining servings: %d\n", *pot);  // Print remaining servings

            // If the pot is empty after taking a serving, notify the cook
            // If there are still servings left, refill the semaphore for the wilds to take the next one.
            if (*pot == 0) {
                sem_post(sem_empty);  // Notify the cook that the pot is empty
            } else {
                sem_post(sem_full);   // Refill the semaphore for the next servings
            }
            
            return 1;  // Success
        } else {
            fprintf(stderr, "Pot is empty in getServingsFromPot().\n");  // Print error if the pot is empty
            return 0;  // Failure
        }
    } else {
        fprintf(stderr, "Error: Shared memory is not initialized.\n");  // Print error if shared memory is not available
        return 0;
    }
}

// Main logic of the savages: waits for the pot to be filled and takes servings
void savages(void)
{
    for (int i = 0; i < NUMITER; i++) {
        sem_wait(sem_full);  // Wait for at least one serving to be available
        sem_wait(sem_pot);   // Acquire the semaphore to ensure mutual exclusion

        if (*pot > 0) {
            getServingsFromPot();  // Get a serving from the pot
        }
        sem_post(sem_pot);  // Release the semaphore after modifying the pot
    }
}

int main(int argc, char *argv[])
{
    // Access the semaphores created by the cook
    sem_pot = sem_open(SEM_POT, 0);  // Open the pot semaphore
    if (sem_pot == SEM_FAILED) {
        perror("Error opening 'pot' semaphore");
        exit(EXIT_FAILURE);
    }

    sem_empty = sem_open(SEM_EMPTY, 0);  // Open the empty semaphore
    if (sem_empty == SEM_FAILED) {
        perror("Error opening 'empty' semaphore");
        exit(EXIT_FAILURE);
    }

    sem_full = sem_open(SEM_FULL, 0);  // Open the full semaphore
    if (sem_full == SEM_FAILED) {
        perror("Error opening 'full' semaphore");
        exit(EXIT_FAILURE);
    }

    // Access the shared memory created by the cook
    int shm_fd = shm_open(SHM_NAME, O_RDWR, 0666);  // Open the shared memory
    if (shm_fd == -1) {
        perror("Error opening shared memory");
        exit(EXIT_FAILURE);
    }

    pot = mmap(NULL, SHM_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);  // Map shared memory into the process address space
    if (pot == MAP_FAILED) {
        perror("Error mapping shared memory");
        close(shm_fd);
        exit(EXIT_FAILURE);
    }

    savages();  // Execute the main logic for the savages

    sem_close(sem_pot);  // Close the semaphores
    sem_close(sem_empty);
    sem_close(sem_full);
    munmap(pot, SHM_SIZE);  // Unmap the shared memory
    // shm_unlink is done by the cook

    return 0;  // Exit the program
}
