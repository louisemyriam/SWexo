#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>

#define NUM_HILOS 10 // Number of threads

// Structure for thread arguments
struct argumentos {
    char prioridad; // Priority
    int entero;     // Thread number
};

/* esto es en un .h
typedef struct {
	int student_id; 
	char NIF[MAX_CHARS_NIF+1];	
	char* first_name;
	char* last_name;
} student_t;
*/

// Thread function
void *thread_usuario(void *arg) {
    struct argumentos *arguments = (struct argumentos *)arg;

    int hilo_num = arguments->entero;       // Extract the thread number
    char prioridad = arguments->prioridad; // Extract the priority

    pthread_t hilo_id = pthread_self(); // Get the thread's ID

    free(arguments); // Free the dynamically allocated memory for arguments

    // Print thread details
    printf("Thread ID: %p - Number: %d - Priority: %c\n", hilo_id, hilo_num, prioridad);
	// p: pointer value, switched it from lu -->cuz of a warning


    pthread_exit(NULL); // Exit the thread
}

int main(int argc, char *argv[]) {
    pthread_t hilo[NUM_HILOS]; // Array to hold thread IDs

    // Create 10 threads
    for (int i = 0; i < NUM_HILOS; i++) {
        // Allocate memory for thread arguments dynamically
        struct argumentos *arguments = malloc(sizeof(struct argumentos));

        if (arguments == NULL) {
            perror("Error allocating memory with malloc\n");
            exit(EXIT_FAILURE);
        }

        arguments->entero = i; // Set thread number

        // Assign priority: 'P' for even threads, 'N' for odd threads
        if (i % 2 == 0) {
            arguments->prioridad = 'P'; // Prioritized
        } else {
            arguments->prioridad = 'N'; // Non-prioritized
        }

        // Create the thread and pass the arguments
        if (pthread_create(&hilo[i], NULL, thread_usuario, arguments) != 0) {
            perror("Error creating the thread\n");
            exit(EXIT_FAILURE);
        }
    }

    // Wait for all threads to finish
    for (int i = 0; i < NUM_HILOS; i++) {
        if (pthread_join(hilo[i], NULL) != 0) {
            perror("Error joining the thread\n");
            exit(EXIT_FAILURE);
        }
    }

    return 0;
}