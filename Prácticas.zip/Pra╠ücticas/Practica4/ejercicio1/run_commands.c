#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/wait.h>

// Function to launch a command in a child process
pid_t launch_command(char** argv) {
    pid_t pid = fork();  // Create a child process
    if (pid == -1) { 
        perror("fork"); // Print error if fork fails
        exit(EXIT_FAILURE); 
    } else if (pid == 0) { 
        // Child process: Execute the command
        execvp(argv[0], argv); // Replace the child process image with the new command
        // If execvp fails
        perror("execvp"); // Print error if execvp fails
        exit(EXIT_FAILURE);
    }
    // Parent process: Return the PID of the child process
    return pid;
}

// Function to parse a command string into an argv array
char** parse_command(const char *cmd, int* argc) {
    size_t argv_size = 10;  // Initial size for the arguments array
    const char *end;
    size_t arg_len;
    int arg_count = 0;
    const char *start = cmd;
    char **argv = malloc(argv_size * sizeof(char*)); // Allocate memory for arguments array

    if (argv == NULL) {
        perror("malloc"); // Print error if memory allocation fails
        exit(EXIT_FAILURE);
    }

    // Skip initial whitespace
    while (*start && isspace(*start)) start++;

    while (*start) {
        if (arg_count >= argv_size - 1) {  // Reallocate space if necessary
            argv_size *= 2;
            argv = realloc(argv, argv_size * sizeof(char*));
            if (argv == NULL) {
                perror("realloc"); // Print error if memory reallocation fails
                exit(EXIT_FAILURE);
            }
        }

        // Find the next space-separated token
        end = start;
        while (*end && !isspace(*end)) end++;

        arg_len = end - start; // Calculate the length of the argument
        argv[arg_count] = malloc(arg_len + 1); // Allocate space for the argument
        if (argv[arg_count] == NULL) {
            perror("malloc"); // Print error if memory allocation fails
            exit(EXIT_FAILURE);
        }
        strncpy(argv[arg_count], start, arg_len); // Copy the argument to the array
        argv[arg_count][arg_len] = '\0'; // Null-terminate the argument string
        arg_count++;

        start = end; // Move to the next token
        while (*start && isspace(*start)) start++;
    }

    argv[arg_count] = NULL; // Null-terminate the array of arguments
    *argc = arg_count; // Store the argument count
    return argv; // Return the arguments array
}

int main(int argc, char *argv[]) {
    char **cmd_argv;  // Array for parsed arguments
    int cmd_argc;     // Number of parsed arguments
    int opt;

    char line[256];   // Buffer to hold lines from the file
    FILE *file;       // File pointer for input files

    int command_count = 0;  // Track command index
    pid_t pids[100];        // Store PIDs for concurrent execution
    int pid_index = 0;      // Index to track PIDs

    char *filename = NULL;  // File name for -s option
    int run_b = 0;          // Flag to indicate if -b is set

    // Parse command-line options
    while ((opt = getopt(argc, argv, "x:s:b")) != -1) {
        switch (opt) {
            case 'x': {
                // Parse and execute a single command
                cmd_argv = parse_command(optarg, &cmd_argc);

                //printf("@@ Running command: %s\n", optarg);
                pid_t pid = launch_command(cmd_argv); // Launch the command in a child process

                int status;
                waitpid(pid, &status, 0); // Wait for the command to finish
                //printf("@@ Command terminated (pid: %d, status: %d)\n", pid, status);

                for (int i = 0; i < cmd_argc; i++) free(cmd_argv[i]); // Free allocated memory
                free(cmd_argv);
                break;
            }

            case 's': {
                filename = optarg; // Store the filename for later use
                break;
            }

           case 'b': {
               /**
                if (filename ==NULL){
                    fprintf (stderr,"The -b option requires the -s option.\n");
                    exit(EXIT_FAILURE);
                }

                file = fopen(filename, "r");
                if (file == NULL) {
                    perror("fopen");
                    exit(EXIT_FAILURE);
                }

                while (fgets(line, sizeof(line), file)) {
                    line[strcspn(line, "\n")] = 0;  // Remove trailing newline
                    printf("@@ Running command #%d: %s\n", command_count, line);

                    cmd_argv = parse_command(line, &cmd_argc);
                    pids[pid_index++] = launch_command(cmd_argv);

                    for (int i = 0; i < cmd_argc; i++) free(cmd_argv[i]);
                    free(cmd_argv);

                    command_count++;
                }
                fclose(file);

                // Wait for all children to finish
                int status;
                for (int i = 0; i < pid_index; i++) {
                    waitpid(pids[i], &status, 0);
                    printf("@@ Command #%d terminated (pid: %d, status: %d)\n", i, pids[i], status);
                }
                break;
            }*/
                run_b = 1; // Set the flag for concurrent execution
                break;
            }

            default:
                fprintf(stderr, "Usage: %s -x \"command\" | -s <file> [-b]\n", argv[0]);
                exit(EXIT_FAILURE);
        }
    }

    // Ensure -b is used with -s
    if (run_b && filename == NULL) {
        fprintf(stderr, "The -b option requires the -s option.\n");
        exit(EXIT_FAILURE);
    }

    // Process the file if -s is specified
    if (filename != NULL) {
        file = fopen(filename, "r"); // Open the file
        if (file == NULL) {
            perror("fopen"); // Print error if file cannot be opened
            exit(EXIT_FAILURE);
        }

        if (run_b) {
            // Concurrent execution of commands from the file
            while (fgets(line, sizeof(line), file)) {
                line[strcspn(line, "\n")] = 0; // Remove trailing newline
                printf("@@ Running command #%d: %s\n", command_count, line);

                cmd_argv = parse_command(line, &cmd_argc); // Parse the command
                pids[pid_index++] = launch_command(cmd_argv); // Launch the command

                for (int i = 0; i < cmd_argc; i++) free(cmd_argv[i]); // Free allocated memory
                free(cmd_argv);

                command_count++;
            }

            // Wait for all child processes to finish
            int status;
            for (int i = 0; i < pid_index; i++) {
                waitpid(pids[i], &status, 0);
                printf("@@ Command #%d terminated (pid: %d, status: %d)\n", i, pids[i], status);
            }
        } else {
            // Sequential execution of commands from the file
            while (fgets(line, sizeof(line), file)) {
                line[strcspn(line, "\n")] = 0; // Remove trailing newline
                printf("@@ Running command #%d: %s\n", command_count, line);

                cmd_argv = parse_command(line, &cmd_argc); // Parse the command
                pid_t pid = launch_command(cmd_argv); // Launch the command
                int status;
                waitpid(pid, &status, 0); // Wait for the command to finish
                printf("@@ Command #%d terminated (pid: %d, status: %d)\n", command_count, pid, status);

                for (int i = 0; i < cmd_argc; i++) free(cmd_argv[i]); // Free allocated memory
                free(cmd_argv);

                command_count++;
            }
        }

        fclose(file); // Close the file
    }

    return EXIT_SUCCESS; // Indicate successful execution
}

/*

to test:

./run_commands -x ls

./run_commands -s test1.txt

./run_commands -b -s test2.txt


*/
