#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>


//Partie A
/*
int main(void)
{
    int fd1,fd2,i,pos;
    char c;
    char buffer[6];

    fd1 = open("output.txt", O_CREAT | O_TRUNC | O_RDWR, S_IRUSR | S_IWUSR);
    write(fd1, "00000", 5);
    for (i=1; i < 10; i++) {
        pos = lseek(fd1, 0, SEEK_CUR);
        if (fork() == 0) {
            // Child 
            sprintf(buffer, "%d", i*11111);
            lseek(fd1, pos, SEEK_SET);
            write(fd1, buffer, 5);
            close(fd1);
            exit(0);
        } else {
            // Parent 
            lseek(fd1, 5, SEEK_CUR);
        }
    }

	//wait for all children to finish
    while (wait(NULL) != -1);

    lseek(fd1, 0, SEEK_SET);
    printf("File contents are:\n");
    while (read(fd1, &c, 1) > 0)
        printf("%c", (char) c);
    printf("\n");
    close(fd1);
    exit(0);
}*/


//Partie B
int main(void)
{
    int i;
    char buffer[6];

    // Open the file in the parent process and write initial zeros
    int fd = open("output.txt", O_CREAT | O_TRUNC | O_RDWR, S_IRUSR | S_IWUSR);
    if (fd < 0) {
        perror("open");
        exit(EXIT_FAILURE);
    }
    write(fd, "00000", 5); // Parent writes initial zeros

    for (i = 1; i < 10; i++) {
        pid_t pid = fork();
        if (pid == 0) {
            // Child process
            fd = open("output.txt", O_WRONLY);
            if (fd < 0) {
                perror("open");
                exit(EXIT_FAILURE);
            }

            // Calculate write position and write
            off_t pos = (i * 10) - 5; // Offset for child data
            sprintf(buffer, "%d%d%d%d%d", i, i, i, i, i); // Generate "11111", "22222", etc.
            lseek(fd, pos, SEEK_SET);
            write(fd, buffer, 5);

            close(fd);
            exit(0); // Child exits
        } else if (pid > 0) {
            // Parent process writes zeros after the child
            wait(NULL); // Wait for the child to finish
            off_t pos = i * 10; // Offset for parent's zeros
            lseek(fd, pos, SEEK_SET);
            write(fd, "00000", 5);
        } else {
            perror("fork");
            exit(EXIT_FAILURE);
        }
    }

    // Parent closes the file and displays contents
    close(fd);
    fd = open("output.txt", O_RDONLY);
    if (fd < 0) {
        perror("open");
        exit(EXIT_FAILURE);
    }
    printf("File contents are:\n");
    char c;
    while (read(fd, &c, 1) > 0)
        printf("%c", c);
    printf("\n");
    close(fd);
    exit(0);
}