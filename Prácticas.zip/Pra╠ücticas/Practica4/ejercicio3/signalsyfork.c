#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <string.h>
#include <errno.h>

pid_t pid_hijo; // Global variable to store the PID of the child process

/* Handler for SIGALRM */
void manejador_SIGALRM(int signo) {
    printf("\nSIGALRM signal received! Terminating child process (PID %d).\n", pid_hijo);
    if (kill(pid_hijo, SIGKILL) == -1) {
        perror("Error sending SIGKILL to child process");
    }
}

/* Function to ignore SIGINT */
void ignorar_SIGINT() {
    struct sigaction sa;
    sa.sa_handler = SIG_IGN; // Ignore SIGINT
    sa.sa_flags = 0;
    sigemptyset(&sa.sa_mask);
    
    if (sigaction(SIGINT, &sa, NULL) == -1) {
        perror("Error setting up the SIGINT handler");
        exit(EXIT_FAILURE);
    }
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s command [arguments]\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    /* Ignore SIGINT in the parent process */
    ignorar_SIGINT();
    printf("Parent process is ignoring the SIGINT signal (Ctrl+C).\n");

    /* Create the child process */
    pid_hijo = fork();

    if (pid_hijo < 0) {
        perror("Error creating the child process");
        exit(EXIT_FAILURE);
    }
    else if (pid_hijo == 0) {
        // Child Process: Execute the command
        printf("Child process (PID %d) executing command: %s\n", getpid(), argv[1]);
        execvp(argv[1], &argv[1]);

        // If execvp fails
        perror("Error executing the command");
        exit(EXIT_FAILURE);
    }

    // Parent Process
    printf("Parent process (PID %d) created child with PID %d\n", getpid(), pid_hijo);

    /* Set up the SIGALRM handler */
    struct sigaction sa_alrm;
    sa_alrm.sa_handler = manejador_SIGALRM;
    sa_alrm.sa_flags = 0;
    sigemptyset(&sa_alrm.sa_mask);
    
    if (sigaction(SIGALRM, &sa_alrm, NULL) == -1) {
        perror("Error setting up the SIGALRM handler");
        exit(EXIT_FAILURE);
    }

    /* Schedule a 5-second alarm */
    printf("Scheduling a 5-second alarm to send SIGALRM.\n");
    alarm(5);

    /* Wait for the child process to finish */
    int estado;
    pid_t pid_espera = waitpid(pid_hijo, &estado, 0);

    if (pid_espera == -1) {
        perror("Error waiting for the child process");
        exit(EXIT_FAILURE);
    }

    /* Check how the child process terminated */
    if (WIFEXITED(estado)) {
        printf("The child (PID %d) terminated normally with exit code %d.\n", pid_espera, WEXITSTATUS(estado));
    }
    else if (WIFSIGNALED(estado)) {
        printf("The child (PID %d) was terminated by signal %d.\n", pid_espera, WTERMSIG(estado));
    }

    printf("Parent process terminating.\n");
    return 0;
}


// Ejemplo de ejecucion: ./signalsyfork sleep 4