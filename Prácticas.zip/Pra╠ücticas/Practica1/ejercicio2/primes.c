/**
 * This program calculates the sum of the first n prime numbers.
 * Optionally, it allows the user to provide the value of n as an argument,
 * which defaults to 10.
 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

/**
 * This function takes an array of integers and returns the sum of its n elements.
 */
int sum(int *arr, int n);

/**
 * This function fills an array with the first n prime numbers.
 */
void compute_primes(int* result, int n);

/**
 * This function returns 1 if the provided integer is prime, and 0 otherwise.
 */
int is_prime(int x);

int main(int argc, char **argv) {

  // Default value of n
  int n = 10;

  // If an argument is provided, update the value of n
  if(argc == 2) { // Correction: "==" is used for comparison
    n = atoi(argv[1]); // Convert the argument to an integer
  }

  // Allocate memory to store the first n prime numbers
  int* primes = (int*)malloc(n * sizeof(int));

  // Calculate the first n prime numbers
  compute_primes(primes, n);

  // Calculate the sum of the prime numbers
  int s = sum(primes, n);

  printf("The sum of the first %d primes is %d\n", n, s);

  // Free the allocated memory
  free(primes);
  return 0;
}

/**
 * Calculates the sum of the elements in an array
 * @param arr Array of integers
 * @param n Number of elements in the array
 * @return The sum of the elements
 */
int sum(int *arr, int n) {
  int i;
  int total = 0;

  // Iterate over the array and sum the elements
  for(i = 0; i < n; i++) {
    total += arr[i]; // Correction: the addition operator was incorrectly written.
  }
  return total;
}

/**
 * Fills an array with the first n prime numbers
 * @param result Array where the prime numbers will be stored
 * @param n Number of prime numbers to calculate
 */
void compute_primes(int* result, int n) {
  int i = 0; // Counter for the primes found
  int x = 2; // Start from 2, the first prime number

  // Until n prime numbers are found
  while(i < n) {
    if(is_prime(x)) {
      result[i] = x; // Store the prime number in the array
      i++; // Increment the prime counter
    }
    x++; // Move to the next number
  }
  return;
}

/**
 * Determines if a number is prime
 * @param x The number to evaluate
 * @return 1 if it is prime, 0 otherwise
 */
int is_prime(int x) {
  // Special case: 2 is prime
  if(x == 2) {
    return 1;
  }

  // If the number is even and greater than 2, it is not prime
  if(x % 2 == 0) {
    return 0;
  }

  // Check odd divisors from 3 up to x
  for(int i = 3; i < x; i += 2) {
    if(x % i == 0) {
      return 0; // If there is a divisor, the number is not prime
    }
  }
  return 1; // If there are no divisors, the number is prime
}

/*to compile:
gcc -o primes primes.c

to test:
./primes n

*/

