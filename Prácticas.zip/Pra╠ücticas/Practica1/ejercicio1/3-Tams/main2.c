#include <stdio.h>

#define ARRAY_SIZE  10 // Define the size of the first array
#define VAR  7         // Define a constant for the size of the second array

// Global variables
int a = 7;            // An integer variable initialized to 7
unsigned long b = 8;  // An unsigned long variable initialized to 8
short c;              // A short variable (uninitialized)
char x;               // A char variable (size is 1 byte)
char* pc;             // A pointer to a char (size is 8 bytes on X64)

// Arrays
int array1[ARRAY_SIZE]; // An integer array of size 10
int array2[VAR];        // An integer array of size 7

// Strings
char* str1 = "STRING OF CHARACTERS"; // Points to a string stored in a read-only memory section
                                     // Size of the pointer is 8 bytes
char str2[] = "STRING OF CHARACTERS"; // A char array that stores a copy of the string in read/write memory
                                      // Length of the string is 20 characters + null character '\0' = 21 bytes

int main()
{
    pc = &x; // Assign the address of 'x' to the pointer 'pc'
    a = 16;  // Change the value of 'a' to 16

    // Print the address and size of various variables and arrays
    printf("Address of a: %p Size: %lu \n", &a, sizeof(a));
    printf("Address of b: %p Size: %lu \n", &b, sizeof(b));
    printf("Address of c: %p Size: %lu \n", &c, sizeof(c));
    printf("Address of x: %p Size: %lu \n", &x, sizeof(x));
    printf("Address of pc: %p Address pointed by pc: %p Size: %lu \n",
           &pc, pc, sizeof(pc));
    printf("Address of array: %p Address of element 0: %p Size of the array: %lu \n",
           array1, &array1[0], sizeof(array1));
    printf("Address of str1: %p Address pointed by it: %p Size: %lu \n",
           &str1, str1, sizeof(str1));
    printf("Address of str2: %p Address pointed by it: %p Size: %lu \n",
           &str2, str2, sizeof(str2));

    return 0;
}
