#include <stdio.h> // Standard input and output library

#define N 5 // Defines a constant for the number of loop iterations
#define min(x,y) ( (x<y)?x:y ) // Macro to calculate the minimum of two values
/* if (x < y) {
        return x;
    } else {
        return y;
    }*/


// Global variables
int a = 7; 
int b = 9; 

int main() {

    char* cad = "Hello world"; // String that will be displayed in each iteration
    int i; 

    // For loop that runs N times (5 in this case)
    for (i = 0; i < N; i++) {
        // Prints the string, the current value of 'a', and 'b'
        printf("%s \t a= %d b= %d\n", cad, a, b);

        a++; // Increments the value of 'a' by 1

        // Assigns to 'a' the minimum value between 'a' and 'b'
        // This ensures that 'a' does not exceed the value of 'b'
        a = min(a, b);
    }

    return 0;
}
