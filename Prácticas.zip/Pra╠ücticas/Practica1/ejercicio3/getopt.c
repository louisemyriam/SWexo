#include <stdio.h>
#include <unistd.h> 
#include <stdlib.h> 
#include <string.h>
#include "defs.h"

char *progname; // Global variable to store the program name (argv[0])

/**
 * @brief  Prints the usage of the tool.
 *         Provides information about the options and how to run the program.
 **/

void usage() { // Displays the program name and its usage
	printf("Usage: %s [ options ] title \n", progname); 
	printf("\n\toptions:\n");
	printf("\t\t-h: display this help message\n");
	printf("\t\t-e: print even numbers instead of odd  (default)\n");
	printf("\t\t-l length: length of the sequence to be printed\n");
	printf("\t\ttitle: name of the sequence to be printed\n");
}

/**
 * @brief  Prints a sequence of odd or even numbers to stdout.
 *
 * @param length Number of elements in the sequence
 * @param type Type of numbers to print (odd or even)
 * @param title Title of the sequence
 **/
void display_numbers(int length, parity_t type, char *title) {
	int i, n;
	int first = (type == ODD) ? 1 : 2;// 1-> impair , 2 -> pair
	/* les ? ca marche comme ca :
	int first;
	if (type == ODD) {
   		 first = 1;
	} else {
    	first = 2;
	}
	*/

	printf("Title: %s\n", title);
	for (i = 0, n = first; i < length; i++, n += 2) { // Generates and prints the sequence
		printf("%d ", n);
	}
	printf("\n");
}

int main(int argc, char *argv[]) {
	int opt; // Variable to store the current option from getopt
	struct options options; // Structure that contains the program's options

	progname = argv[0]; // Stores the prog name

	/* Initializes the default values for the options */
	options.par_mode = ODD; 
	options.lenght = 10;    
	options.title = NULL;  

	/* Command-line options parsing */
	while ((opt = getopt(argc, argv, "hel:")) != -1) {
		switch (opt) {
		case 'h':
			// If the '-h' option is specified, displays the help message and exits the program
			usage();
			exit(0);
		case 'e':
			// If the '-e' option is specified, switches to "even numbers" mode
			options.par_mode = EVEN;
			break;
		case 'l':
			// If '-l' is specified, converts the next argument to an integer to define the length
			options.lenght = strtol(optarg, NULL, 10);
			break;
		default:
			exit(EXIT_FAILURE);
		}
	}
	
	// argc: number of arguments
	// char* optarg: stores the argument passed to the currently recognized option, if it accepts arguments.
	// int optind: represents the index of the next element in argv

	/* Assigns the title if there are additional arguments */
	if (optind < argc) {
		options.title = argv[optind]; // The additional argument is the sequence title
	}

	/* Checks if the title is missing (which is a mandatory argument) */
	if (optind >= argc) { 
		fprintf(stderr, "Invalid title\n");
		usage(); // Displays the usage message
		exit(EXIT_FAILURE); 
	}

    /* Calls the function that prints the sequence */
	display_numbers(options.lenght, options.par_mode, options.title);

	return 0;
}


/*
$ ./getopt hola
Title: hola
1 3 5 7 9 11 13 15 17 19

./getopt -l 3 hola1 
Title: hola1
1 3 5


./getopt -l 4 -e hola2 Title: hola2
2 4 6 8

*/