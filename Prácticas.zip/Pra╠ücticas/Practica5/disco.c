#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

#define CAPACITY 3  // Maximum number of clients allowed in the club at once
#define VIPSTR(vip) ((vip) ? "  vip  " : "not vip")  // Helper macro to print if the client is VIP or not

pthread_mutex_t mutex;  // Mutex for synchronizing access to shared resources
pthread_cond_t queue_normal;  // Condition variable for normal clients waiting
pthread_cond_t queue_vip;  // Condition variable for VIP clients waiting

// Global variables to track the number of clients currently inside, waiting VIPs, and normal clients
int clientes_act = 0;
int vip_waiting = 0;
int normal_waiting = 0;

struct tClientes {
    int id;  // Client ID
    int isvip;  // Flag indicating if the client is VIP (1) or not (0)
    int turno;  // Turn assigned to the client within their group (VIP or normal)
};

// Variables to maintain order of arrival within each group
int turno_act_vip = 0;  // Current turn for VIP clients
int turno_act_normal = 0;  // Current turn for normal clients

/*
• If the club reaches capacity, new clients must wait for someone to exit before entering.
• If there are both VIP and normal clients waiting, VIP clients are given priority. Normal clients must wait for all VIPs to enter first.
• Clients enter one by one in strict order of arrival within their group (normal or VIP), as long as the number of clients inside is less than the capacity (CAPACITY).
*/

// Function to handle normal client entry
void enter_normal_client(int id)
{
    pthread_mutex_lock(&mutex);  // Lock the mutex to ensure thread-safety

    // Wait if the club is full
    if (clientes_act >= CAPACITY) {
        printf("Reached maximum capacity (non-VIP), ID: %d\n", id);  // Print message when capacity is reached for non-VIP clients
        normal_waiting++;  // Increment the waiting normal clients counter
        pthread_cond_wait(&queue_normal, &mutex);  // Wait for a signal from the disco_exit function
        normal_waiting--;  // Decrement waiting clients counter
    }

    clientes_act++;  // Increment the current client count
    turno_act_normal++;  // Update the turn for normal clients

    printf("Client with ID: %d (non-VIP) has entered\n", id);  // Print message when a normal client enters
    pthread_mutex_unlock(&mutex);  // Unlock the mutex
}

// Function to handle VIP client entry
void enter_vip_client(int id)
{
    pthread_mutex_lock(&mutex);  // Lock the mutex to ensure thread-safety

    // Wait if the club is full
    if (clientes_act >= CAPACITY) {
        printf("Reached maximum capacity (VIP), ID: %d\n", id);  // Print message when capacity is reached for VIP clients
        vip_waiting++;  // Increment the waiting VIP clients counter
        pthread_cond_wait(&queue_vip, &mutex);  // Wait for a signal from the disco_exit function
        vip_waiting--;  // Decrement waiting clients counter
    }

    clientes_act++;  // Increment the current client count
    turno_act_vip++;  // Update the turn for VIP clients

    printf("Client with ID: %d (VIP) has entered\n", id);  // Print message when a VIP client enters
    pthread_mutex_unlock(&mutex);  // Unlock the mutex
}

// Function to simulate a client dancing inside the club
void dance(int id, int isvip)
{
    printf("Client %2d (%s) dancing in the disco\n", id, VIPSTR(isvip));  // Print client dancing status (VIP or not)
    sleep((rand() % 3) + 1);  // Simulate dancing by sleeping for a random time between 1 and 3 seconds
}

// Function to handle a client exiting the club
void disco_exit(int id, int isvip)
{
    pthread_mutex_lock(&mutex);  // Lock the mutex to ensure thread-safety
    clientes_act--;  // Decrease the current client count

    // If there is space, notify the next client in the queue to enter
    if (clientes_act < CAPACITY) {
        if (vip_waiting > 0) {
            printf("Notifying VIP clients\n");  // Print message when notifying VIP clients
            pthread_cond_signal(&queue_vip);  // Signal VIP queue to notify the next waiting VIP client
        } else if (normal_waiting > 0) {
            printf("Notifying non-VIP clients\n");  // Print message when notifying non-VIP clients
            pthread_cond_signal(&queue_normal);  // Signal normal queue to notify the next waiting normal client
        }
    }

    printf("Client %d has exited\n", id);  // Print message when a client exits
    pthread_mutex_unlock(&mutex);  // Unlock the mutex
}

// Function for the client thread's work
void *client(void *arg)
{
    struct tClientes *cliente = (struct tClientes *)arg;  // Cast the argument to the client structure
    
    // Handle client entry based on whether they are VIP or not
    if (cliente->isvip == 1) {
        enter_vip_client(cliente->id);  // VIP client enters
    } else {
        enter_normal_client(cliente->id);  // Non-VIP client enters
    }

    // Simulate the client dancing and exiting
    dance(cliente->id, cliente->isvip);
    disco_exit(cliente->id, cliente->isvip);
    free(cliente);  // Free the memory allocated for the client
}

// Main function to manage the clients' threads
int main(int argc, char *argv[])
{
    FILE *file;

    // Check if there are command line arguments
    if (argc < 2) {
        printf("Missing arguments\n");  // Print message if arguments are missing
        exit(EXIT_FAILURE);
    }

    // Open the input file containing client data
    if ((file = fopen(argv[1], "r")) == NULL) {
        printf("Error opening file\n");  // Print error if file can't be opened
        exit(EXIT_FAILURE);
    }

    int num_clientes;

    // Read the number of clients from the file
    if (fscanf(file, "%d", &num_clientes) == 0) {
        printf("Error parsing the input\n");  // Print error if parsing fails
        fclose(file);
        exit(EXIT_FAILURE);
    }

    printf("Number of clients: %d\n", num_clientes);  // Print the number of clients

    pthread_t threads_c[num_clientes];  // Array to store client threads

    // Initialize mutex and condition variables
    pthread_mutex_init(&mutex, NULL);
    pthread_cond_init(&queue_vip, NULL);
    pthread_cond_init(&queue_normal, NULL);

    // Create threads for each client
    for (int i = 0; i < num_clientes; i++) {
        struct tClientes *cliente = malloc(sizeof(struct tClientes));  // Allocate memory for the client

        if (fscanf(file, "%d", &cliente->isvip) == 0) {  // Read if the client is VIP
            printf("Error parsing the input\n");  // Print error if parsing fails
            fclose(file);
            exit(EXIT_FAILURE);
        }

        // Assign the turn based on whether the client is VIP or normal
        if (cliente->isvip == 1) {
            turno_act_vip++;
            cliente->turno = turno_act_vip;  // Assign turn for VIP
        } else {
            turno_act_normal++;
            cliente->turno = turno_act_normal;  // Assign turn for normal clients
        }

        cliente->id = i + 1;  // Assign a unique ID to each client
        pthread_create(&threads_c[i], NULL, client, (void *)cliente);  // Create a new client thread
    }

    // Wait for all client threads to finish execution
    for (int i = 0; i < num_clientes; i++) {
        pthread_join(threads_c[i], NULL);  // Wait for each client thread to finish
    }

    fclose(file);  // Close the input file

    return 0;  // Exit the program
}



/*
tentive du test fait en cours avec les attractions 


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

#define CAPACITY 6
#define CAPACITY_SPEEDY 3
#define SPEEDYSTR(speedy) ((speedy) ? " speedy " : " normal ")

pthread_mutex_t mutex;
pthread_cond_t queue_normal;
pthread_cond_t queue_speedy;

// Otra forma de inicializar
/*
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t normal_queue = PTHREAD_COND_INITIALIZER;
pthread_cond_t speedy_queue = PTHREAD_COND_INITIALIZER;


int clientes_act = 0;
int speedy_waiting = 0;
int normal_waiting = 0;
int cont_speedy = 0;

struct tClientes{

	// id: un identificador de la tarea que corresponde con el orden de creación del hilo.
	// isspeedy: un valor que indique si el cliente es speedy o no.

	int id;
	int isspeedy; 
	int turno; // Turno asignado al cliente dentro de su grupo
};

//Variables para mantener el orden de llegada dentro de cada grupo
int turno_act_speedy = 0; //turno actual para clientes speedy
int turno_act_normal = 0;	// Turno actual para clientes normales

/*
• Si el aforo está completo los nuevos clientes deberán eseperar a que salga algún cliente de la discoteca para poder entrar.
• Si hay esperando clientes speedy y clientes normales, se les dará prioridad a los clientes speedy. Los clientes normales deberán por tanto esperar a que entren los speedy primero.
• Los clientes entrarán de uno en uno en orden estricto de llegada según su grupo (normales o speedys), mientras el número de ocupantes de la discoteca sea menor que el aforo (N).

void enter_normal_client(int id)
{
	pthread_mutex_lock(&mutex);

	if(cont_speedy < CAPACITY_SPEEDY){
        //printf("Client %d ( normal ) waiting on the queue\n",id);
		normal_waiting++;
		pthread_cond_wait(&queue_normal,&mutex);
		normal_waiting--;
    }

    if(speedy_waiting > 0){
        //printf("Client %d ( normal ) waiting on the queue\n",id);
		normal_waiting++;
		pthread_cond_wait(&queue_normal,&mutex);
		normal_waiting--;
    }

    // while(clientes_act >= CAPACITY || speedy_waiting > 0 || cliente->turno != turno_act_normal)
    if(clientes_act >= CAPACITY){
		
		//printf("Client %d ( normal ) waiting on the queue\n",id);
		normal_waiting++;
		pthread_cond_wait(&queue_normal,&mutex);
		normal_waiting--;
	}

	clientes_act++;
	turno_act_normal++;

    printf("Starting client %d ( normal )\n",id);
    printf("Client %d ( normal ) entering the attraction\n",id);

	pthread_mutex_unlock(&mutex);
}

void enter_speedy_client(int id)
{
	pthread_mutex_lock(&mutex);

    printf("Starting client %d ( speedy )\n",id);
    printf("Client %d ( speedy ) entering the attraction\n",id);

    if(cont_speedy >= CAPACITY_SPEEDY){

        printf("Client %d ( speedy ) waiting on the queue\n",id);
        speedy_waiting++; 
		pthread_cond_wait(&queue_speedy,&mutex);
		speedy_waiting--;
    }
    
    // while(clientes_act >= CAPACITY || cliente->turno != turno_act_speedy)
    if(clientes_act >= CAPACITY){
		
		printf("Client %d ( speedy ) waiting on the queue\n",id);
		speedy_waiting++; 
		pthread_cond_wait(&queue_speedy,&mutex);
		speedy_waiting--;
	}

    cont_speedy++; // Contador de speedys
	clientes_act++; // Aumentamos la ocupacion de la discoteca
	turno_act_speedy++;

	pthread_mutex_unlock(&mutex);
}

void enjoy(int id, int isspeedy)
{
	printf("Client %d (%s) enjoying the attraction\n", id, SPEEDYSTR(isspeedy));
	sleep((rand() % 3) + 1);
}

void attraction_exit(int id, int isspeedy)
{
	pthread_mutex_lock(&mutex);
	clientes_act--;

	if (clientes_act < CAPACITY){

		if(speedy_waiting > 0){
			pthread_cond_signal(&queue_speedy);
            cont_speedy--;
		}
		else if(normal_waiting > 0){
			pthread_cond_signal(&queue_normal);
		}
	}

	printf("Client %d ( %s ) leaving the attraction\n", id, SPEEDYSTR(isspeedy));
	pthread_mutex_unlock(&mutex);
}

void *client(void *arg)
{
	struct tClientes *cliente = (struct tClientes *)arg; 
	// Downcasting: struct tClientes cliente = *(struct tClientes *)arg;

	if ( cliente->isspeedy == 1){
		enter_speedy_client(cliente->id);
	}
	else if(cliente->isspeedy==0){
		enter_normal_client(cliente->id);
	}
	
	enjoy(cliente->id,cliente->isspeedy);
	attraction_exit(cliente->id,cliente->isspeedy);
	free(cliente); // solo con puntero
}

int main(int argc, char *argv[])
{
	FILE *file;

	if(argc < 2) {
		printf("Faltan argumentos\n");
		exit(EXIT_FAILURE);
	}

	if ((file = fopen(argv[1], "r")) == NULL){  // Si fopen devuelve NULL, hubo un error
        printf("Error\n");
		exit(EXIT_FAILURE);
	}

	int num_clientes;

	if (fscanf(file,"%d",&num_clientes) == 0){
		printf("Error al hacer el parseo\n");
		fclose(file);
		exit(EXIT_FAILURE);
	}
	
	pthread_t threads_c[num_clientes]; // array clientes

	// IMPORTANTE INICIALIZAR

	pthread_mutex_init(&mutex, NULL); 
	pthread_cond_init(&queue_speedy, NULL);
	pthread_cond_init(&queue_normal, NULL);

	for(int i = 0; i<num_clientes;i++){
		
		struct  tClientes *cliente = malloc(sizeof(struct tClientes));

		if (fscanf(file,"%d",&cliente->isspeedy) == 0){
			printf("Error al hacer el parseo\n");
			fclose(file);
			exit(EXIT_FAILURE);
		}

		if(cliente->isspeedy == 1){
			turno_act_speedy++;
			cliente->turno = turno_act_speedy; // turno para speedy y para normal separarlo
		}
		else{
			turno_act_normal++;
			cliente->turno = turno_act_normal;
		}

		cliente->id = i;

		printf("Client %d is ( %s )\n", cliente->id, SPEEDYSTR(cliente->isspeedy));

		pthread_create(&threads_c[i], NULL, client, (void *) cliente);
	}

	for(int i = 0; i<num_clientes;i++){
		pthread_join(threads_c[i], NULL);
	}

	fclose(file);

	return 0;
}




*/