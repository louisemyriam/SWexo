#include <stdio.h>   // Standard library for input and output
#include <stdlib.h>  // Standard library for utility functions, like exit()
#include <fcntl.h>   // Library for file manipulation (open, flags) for O_RDONLY
#include <unistd.h>  // Library for system calls (read, write, close)
#include <sys/stat.h>

void copy_regular(char *orig, char *dest)
{
    int file_origen, file_destino;
    char buffer[512];   
    int leer;           

    if ((file_origen = open(orig, O_RDONLY)) == -1) {
        perror("Error opening source file");
        exit(EXIT_FAILURE);
    }

    if ((file_destino = open(dest, O_WRONLY | O_CREAT | O_TRUNC, 0644)) == -1) {
        perror("Error opening destination file"); 
        close(file_origen); 
        exit(EXIT_FAILURE);
    }

    while ((leer = read(file_origen, buffer, sizeof(buffer))) > 0) { // 0 indicates EOF and -1 indicates error
        
        if (leer == 512) 
            write(file_destino, buffer, 512);
        else 
            write(file_destino, buffer, leer); // Write the remaining bytes read
    }

    // Closes both files when finished
    close(file_origen);
    close(file_destino);

    if (leer == -1) {
        perror("Error copying\n");  
    }
}

void copy_link(char *orig, char *dest)
{
    struct stat sb;
    size_t size;

    if ((lstat(orig, &sb)) == -1) {
        fprintf(stderr, "Error in lstat\n");
        exit(EXIT_FAILURE);
    }

    size = sb.st_size + 1; 
    printf("Link size: %ld\n", size);

    char *buff;
    
    if ((buff = malloc(size)) == NULL) {
        perror("Memory allocation error");
        exit(EXIT_FAILURE);
    } 

    ssize_t readL = readlink(orig, buff, size);

    if (readL == -1) {
        perror("Error in readLink");
        free(buff);
        exit(EXIT_FAILURE);
    }
    
    buff[readL] = '\0';

    if (symlink(buff, dest) == -1) {
        perror("Error in symlink");
        free(buff);
        exit(EXIT_FAILURE);
    }

    free(buff);
}

int main(int argc, char *argv[])
{
    // Check that the arguments are correct (program name + 2 arguments)
    if (argc != 3) { // argv[0]=./copy ; argv[1]= source file, argv[2]= destination file
        fprintf(stderr, "Usage: %s <source_file> <destination_file>\n", argv[0]);  // Error in standard output
        exit(EXIT_FAILURE);  // End the program with an error code
    }

    // Identify whether the source file is a regular file, 
    // a symbolic link, or another type of file using the lstat system call
    
    struct stat sb;

    if (lstat(argv[1], &sb) == -1) { // lstat(const char, struct stat)
        // Check if the source file is a regular file, symbolic link, or other type of file
        fprintf(stderr, "Error in lstat\n");
        return -1;
    }

    switch (sb.st_mode & S_IFMT) { // Important S_IFMT (bit related to file type)
        // S_IFMT bit related to file type (st_mode)
        case S_IFDIR:  
            printf("directory\n");               
            break;
        case S_IFLNK:  
            printf("symlink\n"); 
            copy_link(argv[1], argv[2]);                
        break;
        case S_IFREG:  
            printf("regular file\n");
            copy_regular(argv[1], argv[2]);
        break;
        default:       
            printf("Error: Unknown file\n");               
        break;
    }
    
    return 0; 
}

//  ./copy2 mylink mylcopy 
