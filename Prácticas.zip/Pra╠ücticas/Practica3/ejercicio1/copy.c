#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

// Function to copy data from one file to another
void copy(int fdo, int fdd) // fdo = source (file_in), fdd = destination (file_out)
{ 
    char buffer[512];      // Buffer to hold data during reading
    ssize_t bytes_read;    // To keep track of bytes read

    // Read and write 
    while ((bytes_read = read(fdo, buffer, 512)) > 0) { // 0 -> EOF, -1 -> erreur

        if (bytes_read == 512)
            write(fdd, buffer, 512); // ecrit la totalite des byte ici qui sont 512
        else
            write(fdd, buffer, bytes_read); // ecrit le rest
    }
    
    if (bytes_read == -1)
        printf("Error in read\n"); 
}

/*
int main(int argc, char *argv[])
{
    int file_in, file_out;

    // Validate correct usage of arguments
    if (argc != 3) {
        printf("Usage: <file_name> <originfile> <destinationfile>\n");
        exit(1);
    }

    // Open the source file in read-only mode
    if ((file_in = open(argv[1], O_RDONLY, 0644)) == -1) {
        printf("ERROR: in the input file %s", argv[1]);
        exit(1);
    }
    
    // Open the destination file for writing (create if it doesn’t exist or truncate if it does)
    if ((file_out = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0644)) == -1) {
        printf("ERROR: in the destination file %s", argv[2]);
        close(file_in); // Close the input file
        exit(1);
    }

    printf("Before copy");
    copy(file_in, file_out);
    close(file_out);
    close(file_in);
    printf("After copy");
    return 0;
}
*/

// Main program
int main(int argc, char *argv[])
{
    int source_file, destination_file;

    
    if (argc != 3) { // argv[0] = ./copy; argv[1] = source file, argv[2] = destination file
        printf("Usage: <origin_file> <destination_file>\n");
        exit(1);
    }
    

    if ((source_file = open(argv[1], O_RDONLY, 0644)) == -1) {
        printf("Error in file %s", argv[1]);
        exit(1);
    }


    if ((destination_file = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0644)) == -1) {
        printf("Error in file %s", argv[2]);
        close(source_file); // Close the source file
        exit(1);
    }

    // Copy content from source to destination
    copy(source_file, destination_file);

    // Close files after the operation is complete !!!!
    close(source_file);
    close(destination_file);

    return 0;
}


/*
to test :
./copy <infile> <outfile>

*/




/*
test qu'on a fait en cours correction du prof:



#include <stdio.h>      // Includes standard input/output functions, such as printf, fopen, fgets...
#include <stdlib.h>     // Includes general functions, such as exit, malloc, free...
#include <sys/stat.h>   // Includes the definition of the stat structure and the lstat function
#include <fcntl.h>      // Includes constants and functions for file control (open, O_RDONLY, etc.)
#include <unistd.h>     // Includes operating system functions (read, write, close, getopt...)
#include <string.h>     // Includes string manipulation functions (strcmp, strlen, strcpy, etc.)
#include <errno.h>      // Includes the global errno variable and error definitions

// Definition of the buffer size used to copy data from the file
#define BUFFER_SIZE 512

// Definition of the maximum size for file paths
#define MAX_PATH 1024

// Function `copy_file`:
// Parameters: 
//   - source: path of the source file (the one we want to copy).
//   - destination: path of the destination file (where the content is copied).
// What it does:
//   1. Opens the source file in read mode.
//   2. Creates/opens the destination file in write mode; if it doesn't exist, it creates it.
//   3. Reads the source file content in blocks (buffers) and writes it to the destination.
//   4. Closes both files.
// If an error occurs, it uses `perror` to print error messages and exits the function.
void copy_file(const char *source, const char *destination) {
    // `open` to open the source file in read mode (O_RDONLY)
    int fdo = open(source, O_RDONLY);
    if (fdo == -1) { // If `open` fails, it returns -1, and we verify the error
        perror("Error opening source file");
        return;
    }

    // `open` to open/create the destination file:
    // O_WRONLY: write mode
    // O_CREAT: create if it doesn't exist
    // O_TRUNC: truncate to zero bytes if it exists, overwriting it.
    // The mode `0644` indicates the permissions with which the file will be created (owner read/write, others read-only).
    int fdd = open(destination, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fdd == -1) { // If opening the destination fails
        perror("Error opening/creating destination file");
        close(fdo); // Close the source file before exiting.
        return;
    }

    // Create a buffer of size `BUFFER_SIZE` to read data from the source.
    char buffer[BUFFER_SIZE];
    ssize_t bytesRead, bytesWritten; // `ssize_t` is a signed integer type for byte counting
    // bytesRead: number of bytes read
    // bytesWritten: number of bytes written

    // Loop: read from the source until no data remains
    // `read` reads up to `BUFFER_SIZE` bytes and returns how many were read.
    // If `read` returns 0, the file is finished.
    // If it returns -1, there's an error.
    while ((bytesRead = read(fdo, buffer, BUFFER_SIZE)) > 0) {
        // `totalWritten` is used to ensure all the read bytes are written
        ssize_t totalWritten = 0;
        while (totalWritten < bytesRead) {
            // Write to the destination: `write` may write fewer bytes than requested,
            // so we repeat until all bytes are written.
            bytesWritten = write(fdd, buffer + totalWritten, bytesRead - totalWritten);
            if (bytesWritten == -1) {
                perror("Error writing to destination file");
                close(fdo);
                close(fdd);
                return; // Exit if there's a write error.
            }
            totalWritten += bytesWritten; // Update how many bytes have been written.
        }
    }

    if (bytesRead == -1) { // If the loop ended due to a read error (`read` returned -1)
        perror("Error reading from source file");
    }

    // Close files
    close(fdo);
    close(fdd);
}

// Main function (entry point of the program).
// argc and argv:
//   - argc: number of arguments passed when running the program (including the program name).
//   - argv: array of strings, each one is an argument.
// Example invocation: ./program -b list.txt -d /destination/path
// Here argc might be 5, and the values in argv would be:
// argv[0] = "./program"
// argv[1] = "-b"
// argv[2] = "list.txt"
// argv[3] = "-d"
// argv[4] = "/destination/path"
int main(int argc, char *argv[]) {
    // Variables to store the name of the file list and the destination directory,
    // which will be obtained using `getopt`.
    char *archivo_lista = NULL;       // Here we store the path of the file containing the list of files to copy
    char *directorio_destino = NULL;  // Here we store the path of the destination directory

    // getopt:
    // This function iterates over the arguments and looks for "options" (such as -b, -d).
    // We pass it a string with the letters of the expected options and a colon if the option requires an argument.
    // For example, "b:d:" means the program expects -b <something> and -d <something>.
    // Each time `getopt` is called, it returns the option found. When no more options are found, it returns -1.
    int opt; // Here we store the value returned by `getopt`.
    
    // If the user doesn't pass 5 arguments (the program name counts as 1, plus 4 for -b something -d something),
    // they might not be using the program correctly, but we don't validate here, instead later.
    // Still, the following line is just for robustness. It's better to verify afterward.
    
    // Call `getopt` in a loop. While `getopt` returns a character (option) different from -1, we process it.
    // ':' after 'b' and 'd' indicates those options require an argument.
    while ((opt = getopt(argc, argv, "b:d:")) != -1) {
        // This switch decides what to do based on the option found by `getopt`.
        switch (opt) {
            case 'b':
                // If the option is 'b', its argument (optarg) is the path of the file list.
                // `optarg` is a global variable that `getopt` fills with the value following the option.
                archivo_lista = optarg;
                break;
            case 'd':
                // If the option is 'd', its argument is the path of the destination directory.
                directorio_destino = optarg;
                break;
            case '?':
                // If an unknown option is found, `getopt` returns '?' and we can show a usage message.
                fprintf(stderr, "Usage: %s -b <file_list> -d <destination_directory>\n", argv[0]);
                exit(EXIT_FAILURE);
                break;
        }
    }

    // After the `getopt` loop, we must verify that we indeed obtained both parameters.
    if (archivo_lista == NULL || directorio_destino == NULL) {
        // If either is missing, we show an error message and exit.
        fprintf(stderr, "Both -b and -d must be specified.\n");
        fprintf(stderr, "Usage: %s -b <file_list> -d <destination_directory>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    // Now we verify if the destination directory exists and is a directory.
    // For this, we use `lstat`, which retrieves information about the file we pass.
    struct stat st; // Structure to store file information
    // lstat(directorio_destino, &st):
    // We pass the path of the destination directory and a reference to `st`.
    // If it returns -1, there was an error (e.g., the directory doesn't exist).
    if (lstat(directorio_destino, &st) == -1) {
        perror("Error verifying destination directory"); // Print the error
        exit(EXIT_FAILURE); // Exit with an error
    }

    // S_ISDIR checks if the file's mode is a directory.
    if (!S_ISDIR(st.st_mode)) {
        fprintf(stderr, "The specified destination is not a directory.\n");
        exit(EXIT_FAILURE);
    }

    // Open the file list to read the filenames.
    FILE *file = fopen(archivo_lista, "r");
    if (!file) {
        // If `fopen` returns NULL, it means an error occurred while opening the file.
        perror("Error opening file list");
        exit(EXIT_FAILURE);
    }

    // Create a character array to read filenames line by line.
    char linea[MAX_PATH];

    // `fgets` reads one line from the file and stores it in "linea". Returns NULL if no more lines can be read.
    while (fgets(linea, sizeof(linea), file)) {
        // Remove the newline character at the end (`fgets` keeps the `\n` if there's space)
        // `strcspn` finds the first '\n' character in "linea" and returns its index.
        // We replace that character with '\0' to terminate the string and avoid the newline.
        linea[strcspn(linea, "\n")] = '\0';

        // Verify if the file in the line is a regular file.
        // We use `lstat` again to get information about this file.
        struct stat st_file;
        if (lstat(linea, &st_file) == -1) {
            // If we can't retrieve information, print an error and move to the next file.
            perror("Error getting file information");
            printf("Ignoring file: %s\n", linea);
            continue; 
        }

        // S_ISREG checks if the file is regular (a "normal" file).
        if (S_ISREG(st_file.st_mode)) {
            // If it's regular, copy it.
            // Construct the destination file name by concatenating the destination directory with the file name.
            char destino[MAX_PATH];
            // `snprintf` writes to `destino`: first the directory, then "/", then the file name.
            // This gives us the full path of the destination file.
            snprintf(destino, sizeof(destino), "%s/%s", directorio_destino, linea);

            // Call `copy_file` to copy it.
            copy_file(linea, destino);

            // Inform the user that it was copied.
            printf("Copied: %s -> %s\n", linea, destino);
        } else {
            // If it's not regular (it could be a directory, link, etc.), don't copy it.
            printf("Ignoring file: %s\n", linea);
        }
    }

    // Close the file list after the loop is complete.
    fclose(file);

    // If we reach this point, the program ends successfully.
    return 0;
}




*/