#include <stdio.h> // For input and output functions.
#include <stdlib.h> // For general utility functions.
#include <sys/types.h>  //and #include <sys/stat.h>: To handle file information.
#include <unistd.h> //: For functions like `lstat`.
#include <dirent.h> //: For directory handling functions like `opendir` and `readdir`.
#include <string.h> //: For string manipulation.

#define PATH_MAX 2048

/* Forward declaration */
int get_size_dir(char *fname, size_t *blocks);

/* Gets in the blocks buffer the size of file fname using lstat. If fname is a
 * directory get_size_dir is called to add the size of its contents.
 */
int get_size(char *fname, size_t *blocks)
{
	struct stat statbuf;
	
	// lstat: lstat()  is  identical to stat(), except that if pathname is a symbolic link, then it returns information about the link  it‐self, not the file that the link refers to.
	if(lstat(fname, &statbuf) == -1){
		perror("Error al hacer lstat\n");
		return -1;
	}

	// if (S_ISDIR(statbuf.st_mode))
	switch (statbuf.st_mode & S_IFMT) {
        case S_IFDIR:
			return get_size_dir(fname, blocks);
		break;
        default:
			*blocks += statbuf.st_blocks;              
		break;
    }

	/* S_IFBLK: block device
    S_IFCHR: character device
    S_IFDIR: directory
    S_IFIFO: FIFO/pipe
	S_IFLNK: symlink
    S_IFREG: regular file
    S_IFSOCK: socket */

	return 0;
}


/* Gets the total number of blocks occupied by all the files in a directory. If
 * a contained file is a directory a recursive call to get_size_dir is
 * performed. Entries . and .. are conveniently ignored.
 */
int get_size_dir(char *dname, size_t *blocks)
{	

	struct stat statbuf;
	
	if(lstat(dname, &statbuf) == -1){
		perror("Error al hacer lstat\n");
		return -1;
	}

	if (!S_ISDIR(statbuf.st_mode)){
		perror("Error: no es un directorio\n");
		return -1;
	}

	DIR *dir = opendir(dname);

	if(dir == NULL){
		perror("Error al abrir el directorio");
		return -1;
	}

	struct dirent *entry;

    while ((entry = readdir(dir)) != NULL) {
        
		// Se omiten las entradas "." y ".." para evitar una recursión infinita al navegar a directorios padre o el directorio actual.
		if (strcmp(entry->d_name, ".") != 0 && strcmp(entry->d_name, "..") != 0) {
            
			char new_path[PATH_MAX];
            snprintf(new_path, PATH_MAX, "%s/%s", dname, entry->d_name);
            
			if (get_size(new_path, blocks) == -1) {
                closedir(dir);
                return -1;
            }
        }
    }

    closedir(dir);
    return 0;  
}

/* Processes all the files in the command line calling get_size on them to
 * obtain the number of 512 B blocks they occupy and prints the total size in
 * kilobytes on the standard output
 */
int main(int argc, char *argv[])
{
	if (argc < 2) {
        fprintf(stderr, "Uso: %s <fichero/directorio>\n", argv[0]);  // Error en la salida estándar
        exit(EXIT_FAILURE);  // Termina el programa con un código de error
    }

	for (int i = 1; i < argc; i++){

		size_t total_bloques = 0;

		if ( get_size(argv[i], &total_bloques) == -1){

			printf("Error al obtener el tamaño\n");
			exit(EXIT_FAILURE);
		}

		printf("%luK %s\n", (total_bloques * 512) / 1024, argv[i]);
	}

	return 0;
}


/*
to test:
./espacio <fichero/directorio>

*/
