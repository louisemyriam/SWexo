#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

// Function to display the contents of a file
void mostrar(char *filename, int numbytes, int lastbytes) {
    int file;
    char buffer[1];
    ssize_t bytes_read;

    // Open the file in read-only mode
    if ((file = open(filename, O_RDONLY)) == -1) {
        perror("Error opening the source file");
        exit(EXIT_FAILURE);
    }

    off_t offset;

    // If the `-e` flag is used
    if (lastbytes == 1) {
        offset = -numbytes;
        if ((lseek(file, offset, SEEK_END)) == -1) {
            perror("Error with lseek\n");
            close(file);
            exit(EXIT_FAILURE);
        }
    }

    // Flags for lseek:
    // SEEK_SET: The file offset is set to `offset` bytes (start of the file + offset)
    // SEEK_CUR: The file offset is set to its current location plus `offset` bytes (current position + offset)
    // SEEK_END: The file offset is set to the size of the file plus `offset` bytes (end of file + offset)

    else {
        offset = numbytes;
        if ((lseek(file, offset, SEEK_SET)) == -1) {
            perror("Error with lseek\n");
            close(file);
            exit(EXIT_FAILURE);
        }
    }

    // Read and display the file contents
    while ((bytes_read = read(file, buffer, sizeof(buffer))) > 0) {
        write(STDOUT_FILENO, buffer, bytes_read); // STDOUT_FILENO (1): Outputs to the standard output
    }

    if (bytes_read == -1) {
        perror("Error reading the file");
    }

    close(file);
}

int main(int argc, char *argv[]) {
    int numbytes;
    int lastbytes = 0; 
    int opt;

    if (argc < 4) {
        fprintf(stderr, "Usage: %s <source_file> <destination_file>\n", argv[0]); // Error message on standard error
        exit(EXIT_FAILURE); // Exit the program with an error code
    }

    /* Parse the command-line options */
    while ((opt = getopt(argc, argv, "en:")) != -1) {
        switch (opt) {
        case 'e':
            lastbytes = 1;
            break;
        case 'n':
            numbytes = atoi(optarg);
            break;
        default:
            exit(EXIT_FAILURE);
        }
    }

    if (optind >= argc) { 
        fprintf(stderr, "Missing file name\n");
        exit(EXIT_FAILURE); 
    }

    char *file = argv[optind];

    mostrar(file, numbytes, lastbytes);

    return 0;
}


//to test :

//./mostrar -n 7 <testfile>
//without -e it skips the number of bytes read

//./mostrar -n 10 -e <testfile>
// with -e --> gives the last bytes read

















/*

int main(int argc, char *argv[])
{
    // Variable declarations
    int opt;                 // For getopt
    long N = 0;              // Default N: 0 bytes
    int flag_e = 0;          // Flag to indicate -e is used
    char *filename;          // File name to process
    int fd;                  // File descriptor
    off_t filesize, offset;  // File size and offset for lseek
    char buffer;             // Buffer to read one byte at a time

    // Argument parsing using getopt
    while ((opt = getopt(argc, argv, "n:e")) != -1) { // quand on met les : ca veut dire qu'apres cette intruction on a beosin d'un arg
        switch (opt) {
            case 'n':
                N = atol(optarg); // Convert optarg to long
                break;
            case 'e':
                flag_e = 1; // Set flag_e to indicate -e was provided
                break;
            default:
                fprintf(stderr, "Usage: %s [-n N] [-e] file\n", argv[0]);
                exit(EXIT_FAILURE);
        }
    }

    // Check for file argument after options
    if (optind >= argc) {
        fprintf(stderr, "Expected file name after options\n");
        fprintf(stderr, "Usage: %s [-n N] [-e] file\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    filename = argv[optind];

    // Open the file in read-only mode
    fd = open(filename, O_RDONLY);
    if (fd == -1) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    // Get the file size using lseek
    filesize = lseek(fd, 0, SEEK_END); //lseek(fd, 0, SEEK_END) moves the file offset to the end and returns the file size in bytes.
    if (filesize == -1) {
        perror("Error getting file size");
        close(fd);
        exit(EXIT_FAILURE);
    }

    // Determine starting position (offset) based on -e flag and N
    if (flag_e) { // If -e is provided, show the last N bytes
        if (N > filesize) N = filesize; // Limit N to filesize
        offset = filesize - N;
    } else { // If -e is not provided, skip the first N bytes
        if (N > filesize) N = filesize; // limit N to filesize
        offset = N;
    }
	


    // Move the file pointer to the calculated offset
    if (lseek(fd, offset, SEEK_SET) == -1) {
        perror("Error seeking to position");
        close(fd);
        exit(EXIT_FAILURE);
    }

    // Read and display the file content byte by byte
    while (read(fd, &buffer, 1) > 0) {
        if (write(STDOUT_FILENO, &buffer, 1) == -1) {
            perror("Error writing to output");
            close(fd);
            exit(EXIT_FAILURE);
        }
    }

    // Close the file descriptor
    close(fd);
    return 0;
}
*/